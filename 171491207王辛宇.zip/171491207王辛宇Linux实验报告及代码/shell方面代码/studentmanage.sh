#!/bin/bash
source ./mysqlconnect.sh
#用来链接myql数据库的密码与地址等都在里面
#mysql -h$HOST -u$User -p$PW 2>/dev/null
#该shell程序用来尝试去实现学生作业管理系统中的子宫能：学生信息管理，
#ps：在作者编写成功该程序后，发现确实可以成功运行该功能，但是在编程成功之后越发感觉如果用c语言的话反而能更加顺畅（哭），作者只不过是尝试使用shell脚本编写语言来模仿c中的一些功能，因此继续使用该程序去编写作业功能显得没有太大的意义

#第一部分：有关登录功能的三函数：loginwinodw,teachlogin,studlogin
#登录界面函数
loginwinodw()
 {
	 echo "欢迎进入登录界面"
         echo "1.教师登录"
         echo "2.学生登录"
         echo "3.退出系统"
         read val
         case $val in
                 1)
                         teachlogin
                         ;;
                 2)
                         studlogin
                         ;;
                 3)
                         exit
                         ;;
         esac
 }

#教师登录
 teachlogin()
 {   
         clear
         echo "输入用户名"
         read name
	 echo "输入密码"
	 read pw
	#该语句用来与数据库进行链接，之后会常用
	 tpw=$(mysql -u$User -p$PW $dbname -N -e "select pw from teacher where name='$name'") 2>/dev/null
	if [ "$tpw" = "$pw" ];then
		teachwindow
	else
		echo "帐号或密码输入错误,请按任意键重新输入"
		read -n1 
		teachlogin
	fi

 }

#学生登录
studlogin()
{
	clear
         echo "请输入用户名/学号"
         read sid
	 echo "请输入密码"
	 read pw
	 spw=$(mysql -u$User -p$PW $dbname -N -e "select spw from student where sid='$sid'") 2>/dev/null
	if [ "$spw" = "$pw" ];then
		export x=$sid #为之后的函数学生修改个人信息所做准备
		studwindow
	else
		echo "帐号或密码输入错误,请按任意键重新输入"
		read -n1 
		studlogin
	fi
}


#第二部分：学生登录系统后所能执行的操作与界面
#学生窗口
studwindow()
{
	
	clear
         echo "1.个人信息"
         echo "2.修改密码"
         echo "3.退出系统"
	 read val
         case $val in
                 1)
                         printme
                         ;;
                 2)
                         alterme
                         ;;

                 3)
                         exit
                         ;;
         esac 
}

#查看个人信息
printme()
{
	clear
		mysql -u$User -p$PW $dbname  -e "select sid as '学号',sname as '姓名',sex as '性别',age as '年级',spw as '密码'  from student where sid='$mynum'" 2>/dev/null
		read -n1 -p "按任意键继续"
		studwindow
	
}

#修改个人密码
alterme()
{
	clear
	read -p "新的密码:" spw
	mysql -u$User -p$PW $dbname  -e "update student set spw='$spw' where sid='$x'" 2>/dev/null
	read -n1 -p "已修改，按任意键继续"
		studwindow
}


#第三部分：教师窗口及其功能teachwindow,printall,addstud,selectstud,delstud
#教师窗口
teachwindow()
{
	
	clear
         echo "1.全体学生名单"
         echo "2.增加学生信息"
         echo "3.查询学生信息"
         echo "4.删除学生信息"
	#在该程序中，作者似乎没有办法去实现修改功能，或者说修改功能在shell中只能通过删除与添加功能的合并来实现
         echo "5.退出"
	 read val
         case $val in
                 1)
                         printall
                         ;;
                 2)
                         addstud
                         ;;
		 3)
			 selectstud
			 ;;
		 4)
			 delstud
			 ;;
                 5)
                         exit
                         ;;
         esac 
}

#输出全体学生信息
printall()
{
	clear
         echo "所有学生信息如下:"
         mysql -u$User -p$PW $dbname  -e "select sid as '学号',sname as '姓名',sex as '性别',age as '年级',spw as '密码' from student" 2>/dev/null
	 
	 read -n1 -p "按任意键继续"
	 teachwindow
}

#录入学生信息
addstud()
{

	clear
         read -p "输入学号:" sid
	 read -p "输入姓名:" sname
	 read -p "输入性别:" sex
	 read -p "输入年级:" age
	 read -p "输入密码:" spw
	em=$(mysql -u$User -p$PW $dbname -N -e "select sname from student where sid='$sid'" ) 2>/dev/null
         if [ "$em" ];then
 		echo "该学号已存在"
		read -n1 -p "按任意键继续"
		teachwindow
                
         else
                mysql -u$User -p$PW $dbname  -e "insert into student values('$sid','$sname','$sex','$age','$spw')" 2>/dev/null
		read -n1 -p "按任意键继续"
		teachwindow
         fi
}
#查询学生信息
selectstud()
{
	clear
	read -p "输入学号:" sid
	em=$(mysql -u$User -p$PW $dbname -N -e "select sname from student where sid='$sid'") 2>/dev/null
	if [ "$em" ];then
		mysql -u$User -p$PW $dbname  -e "select sid as '学号',sname as '姓名',sex as '性别',age as '年级',spw as '密码'  from student where sid='$sid'" 2>/dev/null
		read -n1 -p "按任意键继续"
		teachwindow
	else
		echo "学号不存在"
		read -n1 
		teachwindow
	fi
}

#删除学生信息
delstud()
{
	clear
	read -p "输入学号:" sid
	em=$(mysql -u$User -p$PW $dbname -N -e "select sname from student where sid='$sid'") 2>/dev/null
	if [ "$em" ];then
		mysql -u$User -p$PW $dbname  -e "delete from student where sid='$sid'" 2>/dev/null
		read -n1 -p "已删除，按任意键继续"
		teachwindow
	else
		echo "学号不存在"
		read -n1 
		teachwindow
	fi
}




#menu
loginwinodw

