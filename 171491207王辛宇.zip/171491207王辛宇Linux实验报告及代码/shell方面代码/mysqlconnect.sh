#!/bin/bash
Host=127.0.0.1
User=root
PW=230671
dbname=student

