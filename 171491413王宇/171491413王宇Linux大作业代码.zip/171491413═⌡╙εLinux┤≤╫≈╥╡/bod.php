<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�ǿ�����������</title>
<style type="text/css">
<!--
body,td,th {
	font-size: 25px;
	color: #9999FF;
}
.STYLE1 {color: #CC3300}
.STYLE2 {color: #FF0000}
-->
</style></head>

<body background="im/24.jpg">
<center>
  
    <embed src="../sy/im/xk.mp4" quality="high" loop="-1" width="700" height="400"></embed>
  
</center>
<form action="dl.php" method="post" name="form" onSubmit="return CheckForm();">
<table width="700" border="0" cellspacing="0" cellpadding="2" align="center" style="background:url(im/17.jpg)">
<tr>
    <td colspan="2" align="center" height="120">��ӭʹ���ǿ�������������ϵͳ<span class="STYLE1"></span></td>
  </tr>
  <tr>
	<td colspan="2" align="center"  height="60"><span class="STYLE2"></span>���¼�����˻�</td>
  </tr>
  <tr>
    <td width="305" align="right" height="50">�˺ţ�</td>
    <td width="387" align="left" height="50"><input name="zh" type="text" size="20" maxlength="10"  align="middle"></td>
  </tr>
  <tr>
  <td width="305" align="right" height="50">���룺</td>
    <td width="387" align="left" height="50"><input name="mm" type="text" size="20" maxlength="10"  align="middle"></td>
  </tr>
  <tr>
    <td colspan="2" align="center" height="60"><input name="" type="submit" value="��¼" /></td>
  </tr>
  <tr>
    <td align="right" height="80">������</td>
    <td  align="left" height="80"><a href="zhzc.php" target="_blank">ע���˻�</a> <a href="mmys.php" target="_blank">������ʧ</a></td>
  </tr>
</table>
</form>
<center>
<embed src="im/Slushii - Past Lives.mp3"  loop="-1" width="700" height="80"></embed>
</center>
<?php
	include("left_timer.php");
?>
</body>
</html>
<script language="javascript">
function CheckForm()
{
if(document.form.zh.value.trim()=="")
{alert("�������˺ţ�");document.form.zh.focus();return false;}
if(document.form.mm.value.trim()=="")
{alert("���������룡");document.form.mm.focus();return false;}
return true;
}
</script>