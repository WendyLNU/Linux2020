<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�����ʾ</title>
<style type="text/css">
<!--
body,td,th {
	font-size: 20px;
	color: #9999FF;
}
-->
</style></head>

<body background="im/24.jpg">
<?php
include("ccon.php");
$zzh=$_REQUEST["zh"];
$mmm=$_REQUEST["mm"];
$sqlye="select * from �˻� where �˺�=$zzh ";
$rsye=new com("adodb.recordset");
$rsye->open($sqlye,$db,1,1);
$ye=$rsye->Fields("���")->value; 
?>

<table width="700" border="0" cellspacing="0" cellpadding="2" align="center" style="background:url(im/17.jpg)">
  <tr>
    <td align="center" height="80">����������£�</td>
  </tr>
  <tr>
    <td align="center"  height="80"><?php echo  $ye ?></td>
  </tr>
</table>
<?php
	include("left_timer.php");
?>


</body>
</html>
