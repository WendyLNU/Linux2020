<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�˻�����</title>
<style type="text/css">
<!--
body,td,th {
	font-size: 25px;
	color: #9999FF;
}
.STYLE1 {color: #9999FF}
.STYLE3 {color: #37283F}
-->
</style></head>

<body background="im/24.jpg">
<span class="STYLE1"></span>
<table width="700" border="0" cellspacing="0" cellpadding="2" align="center" style="background:url(im/17.jpg)">
  <tr>
    <td align="center"  height="50">��ѡ����Ҫ������ҵ<span class="STYLE3"></span>��</td>
  </tr>
  <tr>
    <td align="center"  height="150"><a href="cxye.php" target="_blank">��ѯ���</a></td>
  </tr>
  <tr>
    <td align="center"  height="150"><a href="xgmm.php" target="_blank">�޸�����</a></td>
  </tr>
  
</table>
<?php
	include("left_timer.php");
?>

</body>
</html>
