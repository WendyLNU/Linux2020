<?php
include("ccon.php");
$zhh=$_REQUEST["zh"];
$xdmm=$_POST["mm1"]
$sqlxg="select * from �˻� where �˺�=$zhh ";
$rsxg=new com("adodb.recordset");
$rsxg->open($sqlxg,$db,1,1);
$sql="update �˻� set ����='$xdmm' where �˺�=$zhh";

$result=$db->Execute($sql);
if($result)
    echo "<script>{alert('�޸ĳɹ�');location.href='zhgl.php'} </script>";
else 
    echo "<script>{window.alert('�޸�ʧ��');history.bak();} </script>";

?>