<?php
include("ccon.php");
$zh2=$_POST["zh"]
$mm2=$_POST["mm"]
$sqldl="select * from �˻� where �˺�=$zh2 ";
$rsdl=new com("adodb.recordset");
$rsdl->open($sqldl,$db,1,1);
$mm3=$rsdl->Fields("����")->value;
if($mm2==$mm3)
    echo "<script>{alert('��¼�ɹ���');location.href='zhgl.php'} </script>";
else
     echo "<script>{window.alert('��¼ʧ��');history.bak();} </script>";
