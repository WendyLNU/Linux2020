<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�޸�����</title>
<style type="text/css">
<!--
body,td,th {
	font-size: 25px;
	color: #9999FF;
}
-->
</style></head>

<body background="im/24.jpg">
<form action="xgbc.php" method="post" name="xg1" onSubmit="return Check3();">
<table width="700" border="0" cellspacing="0" cellpadding="2"  align="center" style="background:url(im/17.jpg)">
  <tr>
    <td width="350" height="100"  align="right">�������µ�����</td>
    <td width="342" height="100" align="left"><input name="xmm1" type="text" size="20" maxlength="6" align="middle"></td>
  </tr>
  <tr>
    <td align="right" height="100">�ٴ�ȷ��������</td>
    <td align="left" height="100"><input name="xmm2" type="text" size="20" maxlength="6"></td>
  </tr>
  <tr>
    <td colspan="2" align="center" height="150"><input name="" type="submit" value="ȷ���޸�" /></td>
	</tr>
	
</table>
</form>
<?php
	include("left_timer.php");
?>


</body>
</html>
<script language="javascript">
function Check3()
{
if(document.xg1.xmm1.value.trim()=="")
{alert("�������µ����룡");document.xg1.xmm1.focus();return false;}
if(document.xg1.xmm2.value.trim()=="")
{alert("���ٴ�ȷ��������");document.xg1.xmm2.focus();return false;}
if(document.xg1.xmm1.value.trim()!=document.xg1.xmm2.value.trim())
{alert("��������������벻һ�£�");document.xg1.xmm2.focus();return false;}
return true;
}
</script>