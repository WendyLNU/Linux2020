<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�ޱ����ĵ�</title>
</head>

<body>
	<?php
	include_once "I index.php";
	?>
<form action="book_add_save.php" method="post" name="formadd" onSubmit="return CheckForm();">
<h1 align="center">������ͼ����Ϣ</h1>
<table width="600" border="1" cellspacing="0" cellpadding="2" align="center">
  <tr>
    <td width="129" bgcolor="#33CCFF">ID</td>
    <td width="457"><input name="id" type="text" size="60" maxlength="60"></td>
  </tr>
  <tr>
    <td width="129" bgcolor="#33CCFF">����</td>
    <td width="457"><input name="bookname" type="text" size="60" maxlength="60"></td>
  </tr>
  <tr>
    <td bgcolor="#33CCFF">���</td>
    <td><input name="lb" type="text" size="60" maxlength="20"></td>
  </tr>
  <tr>
    <td bgcolor="#33CCFF">����</td>
    <td>
	<input name="zz" type="text" size="60" maxlength="20"></td>
  </tr>
  <tr>
    <td bgcolor="#33CCFF">���ʱ��</td>
    <td>
	<input name="time" type="text" size="60" maxlength="20"></td>
  </tr>

  <tr>
    <td colspan="2" align="center">
	<input name="tj" type="submit" value="�ύ����">&nbsp;
	<input name="qx" type="button" value="ȡ��">
	</td>
  </tr>
</table>
</form>
</body>
</html>
<script language="javascript">
function CheckForm()
{
if(document.formadd.id.value.trim()=="")
   { alert("����ID��"); document.formadd.id.focus(); return false; }
if(document.formadd.bookname.value.trim()=="")
   { alert("����������"); document.formadd.bookname.focus(); return false; }
if(document.formadd.lb.value.trim()=="")
   { alert("�������"); document.formadd.lb.focus(); return false; }
if(document.formadd.zz.value.trim()=="")
   { alert("�������ߣ�"); document.formadd.zz.focus(); return false; }
if(document.formadd.time.value.trim()=="")
   { alert("�������ʱ�䣡"); document.formadd.time.focus(); return false; }
return true;
}
</script>