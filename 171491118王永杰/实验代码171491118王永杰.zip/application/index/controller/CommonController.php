<?php
namespace app\index\controller;
use think\Session;
use think\Controller;
class CommonController extends Controller
{
	protected function _initialize(){
        parent::_initialize();
	}

    protected function check_user(){
        $log_status = Session::get('log_status');
	    return $log_status ? true : false;
    }

    public function msgReturn($success=TRUE, $message='success',$data=NULL){
        $resp = [];
        $resp['message'] = $message;
        $resp['code'] = $success ? 200 : 100;
        if ($success){
            $resp['data'] = $data;
        }
        return $resp;
    }
}