<?php
namespace app\index\controller;
use think\Session;
class AuthController extends CommonController
{
    protected $user_id;
    protected $user_type;

    protected function _initialize(){
        parent::_initialize();
        if(!$this->check_user()){
            $this->redirect('index/Login/login');
        }else{
            $this->user_id = Session::get('user_id');
            $this->user_type = Session::get('user_type');
        }
    }

}