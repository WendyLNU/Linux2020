<?php
namespace app\index\Controller;
use think\Controller;
use app\index\model\User as UserModel;
use app\index\model\Order as OrderModel;
class OrderController extends AuthController
{
    //用户添加托管任务
    public function add(){
        if($this->request->isPost()){
            $data = $this->request->post();
            $data['user_id'] = $this->user_id;
            $randum = date('Ymd');
            for($i=0;$i<5;$i++)
            {$randum = $randum.random_int(0,9);}
            $data['order_id'] = $randum;
            $result = new OrderModel($data);
            $result->allowField(true)->save();
            echo "<script>window.history.go(-2)</script>";
            $this->success('创建成功');
        } else {
            return $this->fetch();
        }
    }

    //我的托管任务
    public function myOrder(){
        $user = OrderModel::get(['user_id' => $this->user_id])->paginate(10);
        $this->assign('list',$user);
        return $this->fetch();
    }
}