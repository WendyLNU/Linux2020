<?php
namespace app\index\controller;
use think\Controller;
use app\index\model\User as UserModel;
use think\Session;
use think\Cookie;
use think\View;
class LoginController extends CommonController
{ 
    protected $user;
    public function _initialize()
    {
        parent::_initialize();
    }

    public function login()
    {
        if($this->check_user())
        {
    		$this->redirect('index/Index/index');
    	}
        if($this->request->isPost())
        {
            $data = [
                'user_name' => $this->request->post('name'),
    			'password' => $this->request->post('password'),
            ];
            $result = UserModel::get($data);
            if($result)
            {
                Session::set('user_id',$result['user_id']);
                Session::set('user_type',$result['is_server']);
                Session::set('log_status','success');
                Cookie::set('username',$result['user_name']);
                $this->assign('type',$result['is_server']);
                return $this->redirect('Index/index/index');
            }else 
            {
                return $this->msgReturn(false,'用户名密码错误',null);
            }   
        }
        else 
        {
            $this->assign('title','用户登录');
            return $this->fetch();
        }
        
    }

    public function register()
    {
        if($this->request->isPost())
        {
            $name = $this->request->post('name');
            $password =$this->request->post('password');
            $service = $this->request->post('service');
            $motto = $this->request->post('motto');
            $UserModel = new UserModel;
            $result = $UserModel->register($name,$password,$service,$motto);
            if($result)
            {
                
                return $this->redirect('Index/login/login');
            }else 
            {
                $this->assign('title','注册失败，请重新注册');
                return $this->fetch();
            }   
        }
        else {
            $this->assign('title','用户注册');
            return $this->fetch();
        }
    }

    public function logout(){
        Session::delete('user_id');
        Session::delete('log_status');
        Cookie::delete('username');
        $this->redirect('index/Login/login');
    }
}