<?php
namespace app\index\controller;
use think\Controller;
use app\index\model\User;

class IndexController extends AuthController
{
    public function index()
    {	
        
        return $this->fetch();
      
      
    }









}

