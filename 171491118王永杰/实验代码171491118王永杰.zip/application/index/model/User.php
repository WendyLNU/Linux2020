<?php
namespace app\index\model;
use think\Model;
class User extends Model
{
    public function checklogin($name,$password)
    {
        $temp_user = $this::get([
            'user_name' =>$name,
            'password' =>$password
            ]);
        return $temp_user;
    }

    public function register($name,$password,$service,$motto)
    {
        $user = new User([
            'user_name' => $name,
            'password' => $password,
            'motto' => $motto,
            'is_server' =>$service
            ]);
        if($user->save()){
            return true;
        }
        else 
        {
            return false;
        }
        
    }
}
