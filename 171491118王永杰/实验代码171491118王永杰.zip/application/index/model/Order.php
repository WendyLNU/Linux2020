<?php
namespace app\index\model;
use think\Model;
class Order extends model{
    public function getStatusAttr($value)
    {
    $status = [0=>'新发布',1=>'正在完成',2=>'完成'];
    return $status[$value];
    }

    
}