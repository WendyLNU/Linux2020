<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:84:"E:\phpstudy_pro\WWW\localhost\test\public/../application/index\view\index\index.html";i:1593499551;s:74:"E:\phpstudy_pro\WWW\localhost\test\application\index\view\public\head.html";i:1593500270;s:74:"E:\phpstudy_pro\WWW\localhost\test\application\index\view\public\menu.html";i:1593505426;s:73:"E:\phpstudy_pro\WWW\localhost\test\application\index\view\public\top.html";i:1593498368;s:76:"E:\phpstudy_pro\WWW\localhost\test\application\index\view\public\footer.html";i:1593500257;}*/ ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>帮一帮</title>

    <!-- Bootstrap -->
    <link href="/test/public/static/css/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="/test/public/static/css/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="/test/public/static/css/vendors/nprogress/nprogress.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="/test/public/static/css/build/css/custom.min.css" rel="stylesheet">
    
  </head>
<!-- bootstrap-daterangepicker -->
<link href="/test/public/static/css/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <!-- menu -->
        <div class="col-md-3 left_col">
    <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;">
            <a href="index.html" class="site_title"><i class="fa fa-paw"></i> <span><?php echo \think\Config::get('website.name'); ?></span></a>
        </div>

        <div class="clearfix"></div>

        <br/>

        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
                <h3>帮一帮托管平台</h3>
                <ul class="nav side-menu">
                    <li><a><i class="fa fa-file-text-o"></i> 托管任务管理 <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo url('index/Order/add'); ?>">添加托管任务</a></li>
                            <li><a href="<?php echo url('index/Order/myorder'); ?>">我的托管任务</a></li>
                            <?php if(\think\Session::get('admin_type') == '1'): ?>
                            <li><a href="<?php echo url('admin/Task/index'); ?>">任务列表</a></li>
                            <li><a href="<?php echo url('admin/OrderService/index'); ?>">服务记录</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <li><a><i class="fa fa-comment-o"></i> 订单评价 <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo url('admin/OrderReview/index'); ?>">查看评价</a></li>
                        </ul>
                    </li>
                </ul>
            </div>

        </div>
        
    </div>
</div>
        <!-- menu -->
        <!-- top navigation -->
          <div class="top_nav">
    <div class="nav_menu">
      <nav>
        <div class="nav toggle">
          <a id="menu_toggle"><i class="fa fa-bars"></i></a>
        </div>

        <ul class="nav navbar-nav navbar-right">
          <li class="">
            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
              <?php echo \think\Cookie::get('username'); ?>
              <span class=" fa fa-angle-down"></span>
            </a>
            <ul class="dropdown-menu dropdown-usermenu pull-right">
              <li><a href="<?php echo url('index/Login/logout'); ?>"><i class="fa fa-sign-out pull-right"></i>注销</a></li>
            </ul>
          </li>

        </ul>
      </nav>
    </div>
  </div>
        <!-- /top navigation -->
      </div>
      <!-- /page content -->
      <!-- footer content -->
      <footer>
  <div class="pull-right">
    帮一帮 - 托管系统 by <a href="/">帮一帮</a>
  </div>
  <div class="clearfix"></div>
</footer>

      <!-- /footer content -->
    </div>
    <script src="/test/public/static/css/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="/test/public/static/css/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="/test/public/static/css/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="/test/public/static/css/vendors/nprogress/nprogress.js"></script>
    <!-- ECharts -->
    <script src="/test/public/static/css/vendors/echarts/dist/echarts.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="/test/public/static/css/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="/test/public/static/css/vendors/moment/min/moment.min.js"></script>
    <script src="/test/public/static/css/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="/test/public/static/css/build/js/custom.js"></script>
    <script src="/test/public/static/css/build/js/app.js"></script>
    <script src="/test/public/static/css/build/js/statistic.js"></script>
    <!-- script -->
  </body>
  </html>
  <script>
    var startTime = getUrlArg('starttime');
    var endTime = getUrlArg('endtime');
  
    var statistic_url = "<?php echo url('admin/Statistic/getOrderStatistic'); ?>?starttime="+startTime+"&endtime="+endTime;
    
    $(function () {
  
      init_echarts();
  
  
    });
  </script>