<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"E:\phpstudy_pro\WWW\localhost\tp\public/../application/index\view\index\index.html";i:1587894813;}*/ ?>
index.html

<body>
<button><?php echo $user['name']; ?></button>
<div><?php echo $user['name']; ?></div>
</body>
