<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"E:\phpstudy_pro\WWW\localhost\test\public/../application/index\view\login\register.html";i:1592318807;}*/ ?>
<!DOCTYPE>
<html>
<head>
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="/test/public/static/css/css.css"> 
</head>
<body>
    <div id="login_form">
    <h1><?php echo $title; ?></h1>
        <form action="<?php echo url('index/login/register'); ?>" method="post">
            <div class="inputBox">
                <div class="inputText">
                    用户：<input type="text" name="name" placeholder="请输入用户名">
                </div>
                <div class="inputText">
                    密码：<input type="password" name="password" checked placeholder="请输入密码">
                </div>
                <div class="inputText">
                    签名：<input type="text" name="motto" checked placeholder="请输入签名">
                </div>
                <div class="inputText">
                    <label><input type="radio" name="service" value="服务人员">服务人员</label>
		            <label><input type="radio" name="service" value="普通用户">普通用户</label>
                </div>
            </div>
            <button type="submit" class="inputButton">注册</button>
            
            
        </form>
    </div>
</body>
</html>