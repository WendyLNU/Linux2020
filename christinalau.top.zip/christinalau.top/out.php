<?php session_start();
$_SESSION['login']=NULL;
$_SESSION['userID']=NULL;
$_SESSION['uName']=NULL;
$_SESSION['admin']=NULL;
$_SESSION['userID']=NULL;
$_SESSION['topicId']=NULL;
?>
<script>
parent.location.href="index.php";

</script>