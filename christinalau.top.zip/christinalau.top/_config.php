<?

define('CODE_WIDTH',         120);
define('CODE_HEIGHT',        28);
define('CODE_FONT_SIZE',     15);
define('CODE_CHARS_COUNT',   5);
define('CODE_LINES_COUNT',   10);
define('CODE_CHAR_COLORS',   "#880000,#008800,#000088,#888800,#880088,#008888,#000000");
define('CODE_LINE_COLORS',   "#DD6666,#66DD66,#6666DD,#DDDD66,#DD66DD,#66DDDD,#666666");
define('CODE_BG_COLOR',      "#FFFFFF");
define('CODE_ALLOWED_CHARS', "ABCDEFGHJKLMNPQRSTUVWXYZ2345689");
define('PATH_TTF',           "fonts");

?>