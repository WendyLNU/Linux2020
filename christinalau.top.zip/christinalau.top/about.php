<html>
<head>
<meta charset="utf-8">
<title>首页</title>
<link href="style/index.css" rel="stylesheet" type="text/css">
<link href="style/backbtn.css" rel="stylesheet" type="text/css">

<script src="JavaScript/back.js"></script>
<style type="text/css">
	body
{
	background-image: url(../images/1.jpg);
	background-repeat: no-repeat;
	background-position: left 0px;
	background-size: cover;	}
</style>
</head>
<body>
	<div style="text-align: center;margin-top: 20%;color: #fff;">
		作者邮箱 christinaliu@tom.com
	</div>
</body>
</html>