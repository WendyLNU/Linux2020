#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
//#include "msg_queue.c"
//#include "status.h"
#include "struct.h"
#include "tools.h"

int unlock(Account acc)
{
    char path[50] = "./data/";
	char ex[8] = ".dat";
	sprintf(path,"%s%ld%s",path,acc.user,ex);

	if(0 == access(path,F_OK))
	{
		Account buf = {};
		int fd = open(path,O_RDWR);
		if(0 != read(fd,&buf,sizeof(Account)))
		{
			if(strcmp(acc.name,buf.name) == 0 && strcmp(acc.id,buf.id) == 0)
			{
				close(fd);
				printf("�����ɹ�\n");
				return 0;
			}
			else
			{
				printf("����������֤����\n");
				close(fd);
				return -1;
			}
		}
		else
		{
			close(fd);
			printf("��ȡ��Ϣʧ��\n");
			return -1;
		}
	}
	else
	{
		printf("���ʺŲ�����\n");
		return -1;
	}
}

int main()
{
	int msgid_ctos = msgget(ftok(".",100),IPC_CREAT|0644);
	if(0 > msgid_ctos)
	{
		perror("msgget");
		return -1;
	}
	int msgid_stoc = msgget(ftok(".",200),IPC_CREAT|0644);
	if(0 > msgid_stoc)
	{
		perror("msgget");
		return -1;
	}

	long user = 0;

	for(;;)
	{
		Msg msg = {};
		// ������Ϣ
		msgrcv(msgid_ctos,&msg,sizeof(Msg),118,MSG_NOERROR);
		//printf("type:%ld\n",msg.type);
		printf("user:%ld\n",msg.acc.user);
		printf("name:%s\n",msg.acc.name);
		printf("id:%s\n",msg.acc.id);
		user = msg.acc.user;
		int result = unlock(msg.acc);

		Msg msg2 = {228};
		if(result == 0)
		{
			msg2.acc.user = user;
			//msg2.flag = 0;
			printf("msg2:%ld\n",msg2.acc.user);
		}
		else
		{
			msg2.acc.user = user + 1;
			//msg2.flag = 0;
			printf("msg2:%ld\n",msg2.acc.user);
		}
		msgsnd(msgid_stoc,&msg2,sizeof(Msg)-sizeof	(msg2.type),0);

		//pause();
	}
	pause();
}
