#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
//#include "msg_queue.c"
//#include "status.h"
#include "struct.h"
#include "tools.h"

long user = 0;//�ʺ�

int a(Account acc)
{
    char path[50] = "./data/";
	char ex[8] = ".dat";
	sprintf(path,"%s%ld%s",path,acc.user,ex);

	Account buf = {};
	int fd = open(path,O_RDWR);
	if(0 != read(fd,&buf,sizeof(Account)))
	{
		printf("���:%.2lf,",buf.money);
		if(buf.money < acc.money)
		{
			printf("����\n");
			return -1;
		}
		else
		{
			user = acc.user;
			return 0;
		}
	}
	else
	{
		printf("��ȡ���ݶ�ʧ\n");
		return -1;
	}
}

int b(Account acc)
{
    char path1[50] = "./data/";
	char ex1[8] = ".dat";
	sprintf(path1,"%s%ld%s",path1,acc.user,ex1);

	if(0 == access(path1,F_OK))
	{

		char path[50] = "./data/";
		char ex[8] = ".dat";
		sprintf(path,"%s%ld%s",path,user,ex);

		Account buf = {};
		int fd = open(path,O_RDONLY);
		if(0 != read(fd,&buf,sizeof(Account)))
		{
			//printf("���:%.2lf\n",buf.money);
		}
		else
		{
			printf("��ȡ���ݶ�ʧ\n");
		}

		Account buf1 = {};
		int fd1 = open(path1,O_RDWR);
		if(0 != read(fd1,&buf1,sizeof(Account)))
		{
			//printf("�Է����:%lf\n",buf1.money);
			buf1.money += acc.money;
			buf.money -= acc.money;
			//printf("�������:%lf\n",buf1.money);
			close(fd);
			close(fd1);

			fd1 = open(path1,O_RDWR);
			if(write(fd1,&buf1,sizeof(Account)) < 0)
			{
				printf("д��Է�����ʧ��\n");
				return -2;
			}
			else
			{
				printf("ת�ʳɹ�\n");
			}

			fd = open(path,O_RDWR);
			if(write(fd,&buf,sizeof(Account)) < 0)
			{
				printf("д����������ʧ��\n");
				return -2;
			}
			else
			{
				printf("��%.2lf\n",buf.money);
				return 2;
			}
			close(fd);
			close(fd1);
		}
		else
		{
			printf("��ȡ�Է����ݶ�ʧ\n");
			return -2;
		}
	}
	else
	{
		printf("�Է��˺Ų�����\n");
		return -2;
	}

}

int main()
{
	int msgid_ctos = msgget(ftok(".",100),IPC_CREAT|0644);
	if(0 > msgid_ctos)
	{
		perror("msgget");
		return -1;
	}
	int msgid_stoc = msgget(ftok(".",200),IPC_CREAT|0644);
	if(0 > msgid_stoc)
	{
		perror("msgget");
		return -1;
	}

	long user1 = 0,user2 = 0;

	for(;;)
	{
		Msg msg = {};
		// ������Ϣ
		msgrcv(msgid_ctos,&msg,sizeof(Msg),114,MSG_NOERROR);
		if(msg.flag == 0)
		{
			//printf("type:%ld\n",msg.type);
			printf("ת���ʺ�:%ld\n",msg.acc.user);
			printf("ת�ʽ��:%.2lf\n",msg.acc.money);
			user1 = msg.acc.user;

			int result = a(msg.acc);

			Msg msg2 = {224};
			if(result == 0)
			{
				msg2.acc.user = user1;
				msg2.flag = 0;
			}
			else
			{
				msg2.flag = -1;
			}
			msgsnd(msgid_stoc,&msg2,sizeof(Msg)-sizeof	(msg2.type),0);

			//pause();
		}
		else
		{
			printf("�����ʺ�:%ld\n",msg.acc.user);
			printf("ת�ʽ��:%.2lf\n",msg.acc.money);
			user2 = msg.acc.user;

			int result = b(msg.acc);

			Msg msg2 = {224};
			if(result != -2)
			{
				msg2.acc.user = user2;
				msg2.flag = 2;
			}
			else
			{
				msg2.flag = -2;
			}
			msgsnd(msgid_stoc,&msg2,sizeof(Msg)-sizeof	(msg2.type),0);
		}
	}
	pause();
}
