<?php 
/* 数据库配置文件 */
define('HOST', '127.0.0.1');
define('USERNAME', 'root');
define('PASSWORD','123456');
define('DB','hospital');
define('DB_CHARSET', 'utf8');
