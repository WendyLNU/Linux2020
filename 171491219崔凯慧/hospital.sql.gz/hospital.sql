-- MySQL dump 10.13  Distrib 5.5.62, for Linux (x86_64)
--
-- Host: localhost    Database: hospital
-- ------------------------------------------------------
-- Server version	5.5.62-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `disease`
--

DROP TABLE IF EXISTS `disease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disease` (
  `id` int(10) unsigned NOT NULL,
  `disName` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disease`
--

LOCK TABLES `disease` WRITE;
/*!40000 ALTER TABLE `disease` DISABLE KEYS */;
INSERT INTO `disease` VALUES (1,'普通内科'),(2,'普通外科'),(3,'心血管内科'),(4,'呼吸内科'),(8,'骨科'),(10,'内分泌科'),(28,'儿科'),(29,'眼科'),(30,'消化内科');
/*!40000 ALTER TABLE `disease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `docname` varchar(45) NOT NULL,
  `position` varchar(45) NOT NULL,
  `department` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `disId` varchar(45) NOT NULL,
  `content` text,
  `age` int(3) NOT NULL,
  `graduateschool` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (1,'刘二','医师','内分泌科','专业擅长：糖尿病及甲状腺等内分泌疾病诊治。\r\n','10',NULL,35,'安徽医科大学\r\n'),(2,'刘三','教授','内分泌科','专业擅长：糖尿病及甲状腺等内分泌疾病诊治。\r\n','10',NULL,53,'安徽医科大学\r\n'),(3,'刘艺','主任医师','普通外科','普通外科主任医师，中国医科大学博士毕业。','2',NULL,40,'中国医科大学'),(4,'马文洲','主任医师','儿科','擅长小儿各系统疑难疾病的诊治，小儿神经系统疾病的脑发育不良、脑炎后遗症、缺血缺氧性脑病后遗症、神经遗传疾病等的诊断治疗、康复评价、康复治疗，手术后患者康复治疗。\r\n','28',NULL,41,'中医药大学'),(5,'王守印','医师','普通外科','擅长皮炎、湿疹、体癣等疾病研究。','2',NULL,49,'锦州医学院\r\n'),(6,'赵刚','主任医师','儿科','擅长自闭症、脑发育不良、脑炎后遗症、发育迟缓、语言发育迟缓、智力低下、口吃、唐氏综合征等儿童神经内科疾病的诊断与治疗，临床经验丰富。\r\n','28',NULL,41,'中医药大学'),(7,'柳侑绮','医师','心血管内科','冠心病（心绞痛、心肌梗死介入检查及治疗），高血压，糖尿病，高血脂\r\n','3',NULL,38,'沈阳医学院'),(8,'刘峰','医师','内分泌科','糖尿病降糖方案的优化，糖尿病并发症防治；甲亢，甲减等疾病的老患者咨询\r\n','10',NULL,34,'安徽医科大学'),(9,'王慧','教授','儿科','擅长儿科的常见病、多发病、流行病的诊断及治疗,血小板减少性紫癜的诊治。对小儿呼吸系统疾病、消化系统疾病、神经系统疾病的诊新和治疗有丰富的临床经验,对急、重危患儿能够明确诊断及抢救治疗。','28',NULL,46,'中医药大学'),(10,'毛云','副主任医师','心血管内科','冠心病，冠心病介入诊疗,高血压病,冠脉微血管疾病\r\n','3',NULL,34,'沈阳医学院'),(11,'罗翔','主任医师','心血管内科','冠心病、动脉硬化、高血压、心肌炎、心肌病、心包疾病\r\n','3',NULL,42,'沈阳医学院'),(12,'刘梅','教授','心血管内科','1994年获中国协和医科大学研究生院博士学位。先后于1996年及2000年赴日本循环器病中心及澳大利亚皇家珀斯医院分别进修学习冠心病基础及介入诊疗各一年。现任中国医学科学院阜外心血管病医院内科主任医师。1987年至今一直在阜外医院心内科（主要是冠心病专科）从事临床、科研及介入诊疗工作。\r\n','3',NULL,53,'中国协和医科大学\r\n'),(13,'袁莱','医师','骨科','颈肩腰腿痛病,颈椎间盘突出症, 腰椎间盘突出症, 腰椎不稳滑脱, 骨性关节炎\r\n','8',NULL,34,'中国医学科学院'),(14,'姜风','主任医师','骨科','骨科疾病，关节疾病，运动损伤，骨折。肩关节损伤，膝关节损伤\r\n','8',NULL,43,'中国医学科学院'),(15,'张爱国','教授','骨科','1、掌握骨科基础知识、基本技术。 2、掌握骨科常见疾病的有关理论知识、临床表现、诊断与鉴别诊断、外科治疗原则及手术适应症。 3、掌握现代骨科检查方法。 4、掌握骨科常用影像学诊断方法。 5 、独立完成手、足部外科手术（如肌腱探查吻合术、指固有动脉探查吻合术、指固有神经探查吻合术、指（趾）骨骨折复位克氏针内固定术等手术）。\r\n','8',NULL,56,'中国医学科学院'),(16,'苏茉莉','主任医师','眼科','毕业于中国医科大学，从事眼科临床工作。具有丰富的临床经验，对近视、屈光不正颇有研究，擅长准分子激光、飞秒激光矫治屈光不正手术与眼表疾病的诊治，是东北较早开展飞秒激光治疗近视的专家之一，临床经验丰富。\r\n','29',NULL,39,'中国医科大学'),(17,'刘芳','主任医师','眼科','视光科主任医师， 斜视手术、RGP、角膜塑形镜验配、屈光不正矫正及弱视的治疗。诊治复杂斜视、儿童疑难眼病及屈光不正有丰富的临床经验	\r\n','29',NULL,40,'中国医科大学'),(18,'周宇','医师','呼吸内科','现任沈阳燕都哮喘病医院担任主治医师职位，从事呼吸疾病诊疗工作多年，对呼吸疾病颇有研究，擅长哮喘、支气管炎、慢阻肺、肺纤维化、支气管扩张、肺大泡、尘肺、咳嗽等疾病，临床经验丰富\r\n','4',NULL,39,'郑州大学第一附属医院'),(19,'曲金华','主任医师','呼吸内科','擅长：呼吸系统疾病，重点为弥漫性间质性肺病、结节病、肺部感染等。\r\n','4',NULL,45,'郑州大学第一附属医院\r\n'),(20,'刘红','教授','呼吸内科','对各种重症肺炎（包括肾病、自身免疫病及移植后因免疫低下所致的重症肺炎）、肺癌、支气管哮喘、慢性支气管炎、慢性阻塞性肺部疾病、肺心病、呼吸衰竭、支气管扩张、肺栓塞、肺脓肿、肺结核、慢性咳嗽、咯血、肺血管病、胸腔积液等胸膜疾病、弥漫性间质性肺疾病、结节病、肺泡蛋白沉积症等的诊治有独到的经验，擅长呼吸系统急危重症及疑难疾病的诊治，熟练气管镜的操作和呼吸机的临床应用，掌握呼吸专业最新进展。','4',NULL,59,'郑州大学第一附属医院'),(21,'顾云彻','教授','眼科','擅长角膜屈光手术、高度近视的诊治、病理性近视的控制，以及眼科疾病和白内障的研究，对各种屈光不正、圆锥角膜、双眼视功能异常的诊治。临床经验丰富','29',NULL,40,'中国医科大学'),(22,'毕姚','医师','消化内科','精于中医又擅长中西医结合辨证施治。从事临床内科消化专业多年。擅长诊治多种反复性、顽固性消化道疾患及老年病症，如：胃炎、胃溃疡、溃疡性结肠炎、便秘、食道炎等。','30',NULL,32,'南方医学院'),(23,'李一','主任医师','普通内科','从事临床、教学科研二十余年，发表过许多论文并获奖。','1',NULL,45,'中国医科大学'),(24,'李二','医师','普通内科','从事临床、教学科研二十余年，发表过许多论文并获奖。','1',NULL,46,'中国医科大学'),(25,'李三','副主任医师','普通内科','从事临床、教学科研二十余年，发表过许多论文并获奖。','1',NULL,47,'中国医科大学'),(26,'李四','医师','普通内科','从事临床、教学科研四十余年，发表过许多论文并获奖。','1',NULL,68,'中国医科大学'),(27,'林立','主任医师','普通外科','本人外科学硕士研究生毕业，多年的临床工作积累了丰富的工作经验，一直立志为患者的健康奉献自己的力量。\r\n','2',NULL,38,'宁夏医科大学总医院'),(28,'周鑫','副主任医师','普通外科','擅长痤疮，皮炎，湿疹等皮肤病治疗。\r\n','2',NULL,48,'锦州医学院'),(29,'周非','教授','儿科','擅长小儿多动障碍、小儿抽动障碍、语言发育迟缓等儿童发育行为疾病的诊断与治疗，临床经验丰富\r\n','28',NULL,46,'中医药大学'),(30,'张雨','教授','呼吸内科','肺癌, 矽肺灌洗，肺结核，呼吸科疑难杂症,睡眠呼吸\r\n','4',NULL,58,'南方医科大学'),(31,'李萍','主任医师','消化内科','从事消化内科工作多年，专业基础深厚、临床经验丰富；尤其在消化疾病、胃食管反流病、急慢性胃炎、消化性溃疡、消化道出血、萎缩性胃炎等消化道癌前疾病的诊断和预防有着独特的诊治方法。\r\n','30',NULL,39,'南方医学院'),(32,'刘玉','教授','消化内科','胃、十二指肠溃疡、各型胃炎，胆囊炎、胰腺炎、结肠炎，高血压、慢性支气管炎急慢性胃肠炎、胆汁反流性胃炎、消化性溃疡、胃结石、胃黏膜脱垂症、胃肠功能紊乱、结肠炎、便秘、等疾病的诊断与治疗。','30',NULL,48,'南方医学院');
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical`
--

DROP TABLE IF EXISTS `medical`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical` (
  `id` int(11) NOT NULL,
  `mname` varchar(200) NOT NULL,
  `rules` varchar(80) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `thumb` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical`
--

LOCK TABLES `medical` WRITE;
/*!40000 ALTER TABLE `medical` DISABLE KEYS */;
INSERT INTO `medical` VALUES (1,'芩黄喉症胶囊','一盒','芩黄喉症胶囊',45.00,'./images/m.jpg'),(2,'阿奇霉素','一盒','阿奇霉素',30.00,'./images/aqms.jpg'),(3,'蓝芩口服液','10ml*12支/盒','用于急性咽炎、肺胃实热证所致的咽痛、咽干、咽部灼热。',49.80,'./images/lqkfy.jpg'),(4,'999感冒灵颗粒','1盒','感冒头痛发热鼻塞流涕感冒药冲剂',15.00,'./images/999.jpg'),(5,'以岭连花清瘟胶囊','1盒','感冒药解毒流感发热高热鼻塞',13.00,'./images/lhqyjn.jpg'),(6,'聚乙烯醇滴眼液 ','0.8ml*10支*1盒','人工泪液，眼睛干涩，抗眼疲劳',29.80,'./images/jyxdyy.jpg'),(7,'盐酸西替利嗪片','10mg*10片/盒','季节性鼻炎、常年性过敏性鼻炎',36.00,'./images/yansuan.jpg'),(8,'星鲨维生素D滴剂','5盒（150粒）','补充维生素',225.00,'./images/wssD.jpg'),(8,'雷氏 猴头菌片','1盒','养胃和中。用于慢性浅表性胃炎引起的胃痛。',33.00,'./images/htj.jpg'),(9,'同溢堂 益安宁丸','112粒*3瓶 ','家中老人常备，治疗冠心病',1580.00,'./images/tyt.jpg');
/*!40000 ALTER TABLE `medical` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `morder`
--

DROP TABLE IF EXISTS `morder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `morder` (
  `id` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `mname` varchar(200) NOT NULL,
  `userId` int(11) NOT NULL,
  `username` varchar(80) NOT NULL,
  `buytime` datetime NOT NULL,
  `paystatue` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `morder`
--

LOCK TABLES `morder` WRITE;
/*!40000 ALTER TABLE `morder` DISABLE KEYS */;
INSERT INTO `morder` VALUES (1,1,'芩黄喉症胶囊',1,'testuser','2020-04-26 15:55:05','未缴费'),(0,1,'芩黄喉症胶囊',1,'testuser','2020-04-27 13:54:15','未缴费'),(0,1,'芩黄喉症胶囊',1,'testuser','2020-05-19 17:06:05','未缴费'),(0,2,'阿奇霉素',1,'testuser','2020-05-19 22:56:03','未缴费'),(0,4,'999感冒灵颗粒',11,'amy111','2020-05-20 12:36:56','未缴费'),(0,3,'蓝芩口服液',11,'amy111','2020-05-21 10:42:48','未缴费'),(0,5,'以岭连花清瘟胶囊',11,'amy111','2020-05-21 10:42:52','未缴费'),(0,1,'芩黄喉症胶囊',1,'testuser','2020-05-25 10:12:52','未缴费');
/*!40000 ALTER TABLE `morder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `docId` varchar(45) NOT NULL,
  `docname` varchar(45) NOT NULL,
  `docDepartment` varchar(45) NOT NULL,
  `userId` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `bookdate` varchar(45) NOT NULL,
  `timeFrame` varchar(45) NOT NULL,
  `cost` varchar(45) NOT NULL,
  `paystatue` varchar(45) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES ('6','刘翠花','心肌梗塞','2','admin','2017-02-21','14:30-15:30','5','已受理',1),('19','用例','斜视','2','admin','2017-02-21','8:30-9:30','5','已受理',2),('2','王五','糖尿病','1','testuser','2017-02-23','8:30-9:30','5','已受理',4),('2','王五','糖尿病','1','testuser','2017-02-28','8:30-9:30','5','已缴费',5),('5','王守印','高血压','1','testuser','2017-02-23','14:30-15:30','5','未缴费',6),('7','柳侑绮','偏头痛','1','testuser','2020-04-26','8:30-9:30','5','未缴费',7),('5','王守印','内科','1','testuser','2020-04-27','14:30-15:30','5','未缴费',8),('1','刘二','内分泌科','11','amy111','2020-05-20','8:30-9:30','5','未缴费',9),('2','刘三','内分泌科','11','amy111','2020-05-20','9:30-10:30','5','未缴费',10),('1','刘二','内分泌科','11','amy111','2020-05-21','8:30-9:30','5','未缴费',11),('1','刘二','内分泌科','1','testuser','2020-05-25','8:30-9:30','5','未缴费',12),('2','刘三','内分泌科','1','testuser','2020-05-25','8:30-9:30','5','未缴费',13),('3','刘艺','普通外科','1','testuser','2020-05-25','14:30-15:30','5','未缴费',15);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `realname` varchar(45) NOT NULL,
  `identity` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'testuser','testuser','李奕成','445381199502046335','18825070698'),(11,'amy111','123456','南宫希','210105111102122345','13990909090');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-25 10:23:36
