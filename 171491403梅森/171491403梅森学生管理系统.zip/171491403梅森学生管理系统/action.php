<?php 
include "connect.php"; 
switch($_GET['action']){
//�������ӹ���
case 'add':
$id=$_POST['id'];
$name=$_POST['name'];
$sex=$_POST['sex'];
$age=$_POST['age'];
$grade=$_POST['grade'];
$class=$_POST['class'];

$sql="insert into student(id,name,age,sex,grade,class) values ('{$id}','{$name}','{$age}','{$sex}','{$grade}','{$class}')";
//$rw = $db->exec($sql);
$rw=mysql_query($sql,$db);
/*if($rw>0){echo"<script>alert('���ӳɹ�');</script>";}
else{echo"<script>alert('����ʧ��');</script>";}*/
header('Location: index.php');
break;

//����ɾ������
case 'del':
$id=$_POST['id'];
$sql="delete from student where id={$id}";
$rw=mysql_query($sql,$db);
header('Location: index.php');
break;

//�����޸Ĺ���
case 'edit';
$id=$_POST['id'];
$name=$_POST['name'];
$sex=$_POST['sex'];
$age=$_POST['age'];
$grade=$_POST['grade'];
$class=$_POST['class'];
$sql="update student set name='{$name}',age='{$age}',sex='{$sex}',grade='{$grade}',class='{$class}' where id={$id}";
print $sql;
$rw=mysql_query($sql,$db);
header('Location: index.php');
break;














default:
header('Location: index.php');
break;


}












?>