<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>ѧ����Ϣ</title>
<link type="text/css" href="back.css" rel="stylesheet">
</head>

<body>
<a href="menu.php" target="_self">���ز˵�</a>
<center><h1>ѧ����Ϣ</h1></center>

</body>
</html>
<?php 
include "connect.php";
$result = mysql_query("Select * From student");

echo"<center>";
echo"<table border='1' width='500'><tr><th>ѧ��</th><th>����</th><th>�Ա�</th><th>����</th><th>�꼶</th><th>�༶</th></tr>";
while($row=mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>".$row['id']."</td>";
echo "<td>".$row['name']."</td>";
echo "<td>".$row['sex']."</td>";
echo "<td>".$row['age']."</td>";
echo "<td>".$row['grade']."</td>";
echo "<td>".$row['class']."</td>";
}

echo"</table>";
echo"</center>";
mysql_close($db);

?>


