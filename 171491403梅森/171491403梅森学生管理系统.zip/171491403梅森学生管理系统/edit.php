<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�޸���</title>
<link  href="back.css" type="text/css"  rel="stylesheet">
</head>

<body>
<center>

<form action="action.php?action=edit" method="post">
<h3>������Ҫ�޸�ѧ����Ϣ��ѧ��</h3>
<input type="hiden" name="id" value="<?php echo $student['name']; ?>">
<br/><br/><br/><br/><br/><br/><br/><br/>
<table>

<tr>
<td>����</td>
<td><input type="text" name="name" maxlength="5"></td>
</tr>
<tr>
<td>�Ա�</td>
<td><input type="radio" name="sex"  value="��">��</td>
<td><input type="radio" name="sex" value="Ů">Ů</td>
</tr>
<tr>
<td>����</td>
<td><input type="text" name="age" maxlength="3"></td>
</tr>
<tr>
<td>�꼶</td>
<td><input type="text" name="grade" maxlength="3"></td>
</tr>
<tr>
<td>�༶</td>
<td><input type="text" name="class" maxlength="3"></td>
</tr>
<tr>
<td><input type="submit" value="�޸�"></td>
<td><input type="reset" value="����"></td>
</tr>
</table>








</form>














</center>








</body>
</html>
