<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>������</title>
<link type="text/css" href="back.css" rel="stylesheet">
</head>

<body>
<a href="menu.php" target="_self">���ز˵�</a>
<center>
<form action="seek.php" method="post">
<h3>�����ѯ��ѧ��ѧ��</h3>
<input  name="id" type="text" maxlength="5">
<br/>
<input type="submit" value="����">
<input type="reset" value="����">






</form>
</center>
</body>
</html>
<?php 
include "connect.php";
$id=$_POST['id'];
$result = mysql_query("Select * From student where id={$id}");

echo"<center>";
echo"<h1>ѧ����Ϣ</h1>";
echo"<table border='1' width='500'><tr><th>ѧ��</th><th>����</th><th>�Ա�</th><th>����</th><th>�꼶</th><th>�༶</th></tr>";

while($row=@mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>".$row['id']."</td>";
echo "<td>".$row['name']."</td>";
echo "<td>".$row['sex']."</td>";
echo "<td>".$row['age']."</td>";
echo "<td>".$row['grade']."</td>";
echo "<td>".$row['class']."</td>";
}

echo"</table>";
echo"</center>";
mysql_close($db);

?>