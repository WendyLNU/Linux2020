<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>������</title>
<link type="text/css" href="back.css" rel="stylesheet">
</head>

<body>

<center><h3>����ѧ����Ϣ</h3>
<form action="action.php?action=add" method="post">
<table>
<tr>
<td>ѧ��</td>
<td><input type="text" name="id" maxlength="10" ></td>
</tr>
<tr>
<td>����</td>
<td><input type="text" name="name" maxlength="5"></td>
</tr>
<tr>
<td>�Ա�</td>
<td><input type="radio" name="sex"  value="��">��</td>
<td><input type="radio" name="sex" value="Ů">Ů</td>
</tr>
<tr>
<td>����</td>
<td><input type="text" name="age" maxlength="3"></td>
</tr>
<tr>
<td>�꼶</td>
<td><input type="text" name="grade" maxlength="3"></td>
</tr>
<tr>
<td>�༶</td>
<td><input type="text" name="class" maxlength="3"></td>
</tr>
<tr>
<td><input type="submit" value="����"></td>
<td><input type="reset" value="����"></td>
</tr>
</table>








</form>








</center>
</body>
</html>
