<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr bgcolor="#0033CC">
    <td align="center" style="color:#FF0000">�γ�˼��</td>
  </tr>
</table>
<marquee direction="up" height="70" scrollamount="1" scrolldelay="1" onmouseout="this.start();" onmouseover="this.stop();">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<?php
$sql = "select bigclassname,count(*) as bc from news where bigclassname in (Select bigclassname From bigclass where sp) group by bigclassname ";
$rs=new com("adodb.recordset");
$rs->open($sql,$db,1,1);//ִ�����,���ؼ�¼��
while(! $rs->eof)
{
?>  
  <tr>
    <td ><a href="class_list.php?cn=<?php echo $rs->Fields("bigclassname")->value; ?>" target="_blank"><?php echo $rs->Fields("bigclassname")->value; ?></a></td><td ><?php echo $rs->Fields("bc")->value; ?>������</td>
  </tr>
<?php
$rs->MoveNext(); 
}
$rs=NULL;
?> 
</table>
</marquee>