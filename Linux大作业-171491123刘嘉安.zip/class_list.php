<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>���ŷ���</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#535353" leftmargin="0" topmargin="0">
<?php
include("conn.php");
include("top.php");
$ccc = $_GET["cn"];
?>
<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#FF99FF">
    <th colspan="5"><?php echo $ccc ?></th>
  </tr>
  <tr bgcolor="#FFCCFF">
    <td width="74" align="center">Nid</td>
    <td width="467" align="center">����</td>
    <td width="79" align="center">����</td>
    <td width="67" align="center">����ʱ��</td>
    <td width="71" align="center">�����</td>
  </tr>
<?php
$sql = "Select * From news where bigclassname='$ccc'";
$rs=new com("adodb.recordset");
$rs->open($sql,$db,1,1);//ִ�����,���ؼ�¼��
while(! $rs->eof)
{
?>  
  <tr bgcolor="#FFFFFF">
    <td><?php echo $rs->Fields("nid")->value; ?></td>
    <td><a href="news_disp.php?xwh=<?php echo $rs->Fields("nid")->value; ?>" target="_blank"><?php echo $rs->Fields("title")->value; ?></a></td>
    <td><?php echo $rs->Fields("user")->value; ?></td>
    <td><?php echo $rs->Fields("infotime")->value; ?></td>
    <td><?php echo $rs->Fields("hits")->value; ?></td>
  </tr>
<?php
$rs->MoveNext(); 
}
$rs=NULL;
?>  
</table>


</body>
</html>
