<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>������ѧ������վ</title>
<link href="css.css" rel="stylesheet" type="text/css">
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#535353" topmargin="0" leftmargin="0">
<?php
include("conn.php");
include("func.php");
include("top.php");
include("body.php");


 ?>
</body>
</html>
