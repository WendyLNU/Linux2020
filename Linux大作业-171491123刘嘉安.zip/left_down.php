<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr bgcolor="#0033CC">
    <td align="center" style="color:#FFFFFF">��Դ����</td>
  </tr>
  <tr>
    <td align="center"><img src="images/down.gif" /></td>
  </tr>
</table>
