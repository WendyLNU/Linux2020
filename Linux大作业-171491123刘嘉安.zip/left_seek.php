<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr bgcolor="#0033CC">
    <td align="center" style="color:#FFFFFF">���Ų�ѯ</td>
  </tr>
  <tr>
    <td align="center">
	<form action="seek_list.php" method="post" name="formseek" target="_blank">
	<input name="kkk" type="text" size="20" maxlength="20"><br>
	<input name="ppp" type="radio" value="bt" checked>����
	<input name="ppp" type="radio" value="nr" >����<br>
	<input name="" type="submit" value="��ѯ">
	</form></td>
  </tr>
</table>
