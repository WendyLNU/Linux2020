<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�������</title>
</head>

<body bgcolor="#535353" leftmargin="0" topmargin="0">
<?php 
include("conn.php");//%db
include("top.php");
$xwid=$_GET["xwh"];
$sqlupd="update news set hits=hits+1 where nid=$xwid";//ͳ�Ƶ����
$db->Execute($sqlupd);



$sql = "Select * From news where nid=$xwid ";
$rs=new com("adodb.recordset");
$rs->open($sql,$db,1,1);//ִ�����,���ؼ�¼�� 
?>

<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#FFCC00">
    <th><?php echo $rs->Fields("title")->value; ?></th>
  </tr>
  <tr bgcolor="#FFFF66">
    <td>
	�������<?php echo $rs->Fields("bigclassname")->value; ?><br>
	���ߣ�<?php echo $rs->Fields("user")->value; ?><br>
	����ʱ�䣺<?php echo $rs->Fields("infotime")->value; ?><br>
	����ʣ�<?php echo $rs->Fields("hits")->value; ?>
	</td>
  </tr>
  <tr bgcolor="#FFFF99">
    <td><?php echo $rs->Fields("content")->value; ?></td>
  </tr>
</table>

</body>
</html>
