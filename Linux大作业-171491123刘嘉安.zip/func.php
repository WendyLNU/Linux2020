<?php function ad($c,$n,$a) {?>
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr bgcolor="#0099FF">
    <td width="53%"><img src="images/sub.gif" align="absmiddle"><?php echo $c; ?></td>
    <td width="36%">&nbsp;</td>
    <td width="11%"><a href="class_list.php?cn=<?php echo $c; ?>" target="_blank">more...</a></td>
  </tr>
<?php
include("conn.php");
$sqlf="select top $n * from news where bigclassname='$c' order by hits desc";
$rsf=new com("adodb.recordset");
$rsf->open($sqlf,$db,1,1);//ִ�����,���ؼ�¼��
$js=0;
while(! $rsf->eof&& $js<$n)
{
?> 
  <tr>
    <td style="border-bottom:#FF0000 dotted 1px"><a href="news_disp.php?xwh=<?php echo $rsf->Fields("nid")->value; ?>" target="_blank"><?php echo $rsf->Fields("title")->value; ?></a></td>
    <td style="border-bottom:#FF0000 dotted 1px"><?php echo $rsf->Fields("infotime")->value; ?></td>
    <td style="border-bottom:#FF0000 dotted 1px"><?php echo $rsf->Fields("hits")->value; ?></td>
  </tr>
<?php
$rsf->MoveNext(); $js++;
}
$rsf=NULL;
?>  
</table>
<embed src="images/<?php echo $a ;?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer"  width="578" height="90">
<?php }?>