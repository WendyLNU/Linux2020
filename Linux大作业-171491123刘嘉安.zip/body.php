<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr>
    <td width="200" background="images/classbg.gif">
	<?php
	include("left_timer.php");
	include("left_seek.php");
	include("left_sizn.php");
	include("left_down.php");
	?>
    </td>
    <td width="578" bgcolor="#FFFFFF" valign="top">
<?php
$sql = "Select * From bigclass where homepage";
$rs=new com("adodb.recordset");
$rs->open($sql,$db,1,1);//ִ�����,���ؼ�¼��
while(! $rs->eof)
{
$ccc=$rs->Fields("bigclassname")->value;
$nnn=$rs->Fields("rmax")->value;
$aaa=$rs->Fields("ad")->value;
ad($ccc,$nnn,$aaa);
$rs->MoveNext(); 
}
$rs=NULL;
?>

	</td>
  </tr>
</table>
