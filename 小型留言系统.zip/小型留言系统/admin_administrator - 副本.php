<?php
include_once("admin_head.php");//引入后台公共头文件
checkadmin();//判断当前用户是否管理员
/**************/
$action=isset($_GET['action'])?$_GET['action']:"list";//三元操作符，根据action变量获得当前要执行的动作
switch($action){//switch语句，根据$action来执行相应的动作
	case "insert"://插入或编辑，根据是否传递id来判断，如果传递了则为编辑，如果没有传递则为插入
		$Arr=array();
		if(isset($_GET['id'])&&$_GET['id']){
			$id=intval($_GET['id']);
			$Arr=getone("select * from administrator where id='$id'");//如果是当前动作是编辑，从数据库里读取需要编辑的记录
			$Arr=fromTableInForm($Arr);//安全过滤处理，见函数定义
		}
		setFormSource();//防止表单重复提交
		?>
		<script>
		function check(){
			if(!$('input[name=username]').val()){alert('用户名不能为空');$('input[name=username]').focus();return false;}
			<?php if(!$id){?>
			if(!$('input[name=password]').val()){alert('密码不能为空');$('input[name=password]').focus();return false;}
			<?php }?>
		}
		</script>
		<form action='?action=save&id=<?php echo $id?>' method='post'  onsubmit='return check()' class='myform' >
		<input name='username' style='width:280px;' placeholder="请设置登录账号" value='<?php echo $Arr['username']?>'><br>
		<input name='password' type='password' placeholder="请设置登录密码" style='width:280px;' ><br> 
        <input name='realname' placeholder="请输入真实姓名" style='width:280px;' value='<?php echo $Arr['realname']?>'><br>
		<input name='age' placeholder="请输入用户年龄" style='width:280px;' value='<?php echo $Arr['age']?>'><br>
		<select name='gender' style='width:280px;'><option>男</option><option <?php echo select("女",$Arr['gender'])?>>女</option></select><br> 
		<input type='submit' value='保存' class='submit'>
		</form>
		<?php
	break;
	  
	case "save":
	    //保存插入或编辑的数据到数据库，属于插入还是编辑，根据是否传递了id来判断
		checkFormSource();//判断数据来源是否合法，防止表单重复提交
		$_POST=escapeArr($_POST);	
		if(isset($_GET['id'])&&$_GET['id']){
			if(!$_POST['password']) unset($_POST['password']);
			else $_POST['password']=md5($_POST['password']);
			$id=intval($_GET['id']);
			$find=getone("select id from administrator where username='{$_POST['username']}' and id!=$id");
			if($find['id'])alert("该用户已存在","?action=list");
			update("administrator",$_POST,"id=$id");//执行编辑，见update函数定义
		}
		else{
			$find=getone("select id from administrator where username='{$_POST['username']}'");
			if($find['id'])alert("该用户已存在","?action=list");
			$_POST['password']=md5($_POST['password']);
			insert("administrator",$_POST);//执行插入，见insert函数定义
		}
		alert("操作成功！","?action=list");
	break;	 
	  
	case "alldel":
		//删除或批量删除，如果传递的allidd则为批量删除，如果传递的是id则为单条删除
		$key=isset($_POST["allidd"])&&$_POST["allidd"]?$_POST["allidd"]:array(intval($_GET['id']));
		for($i=0;$i<count($key);$i++){
			$find=getone("select id from administrator where id!={$key[$i]}");
			if($find['id']) query("delete from administrator where id={$key[$i]}"); 
		}
		alert("成功删除".count($key)."条信息！","?action=list");
	break;
	  
	case "list":
		//管理员列表
		echo "<form action='?action=list' method='post'>
		<input name='username' placeholder='搜索用户' value='{$_REQUEST['username']}' style='height:30px;margin-left:0;' >
		<input type='submit' value='搜索'> <input type='button'  onclick=\"location='?action=insert'\" value='新增'> </form>";   
		$fsql="";$fpage="";//初始查询条件语句
		if(isset($_REQUEST['username'])&&$_REQUEST['username']){
			//如果传递了username则根据username检索数据库
			$fsql.=" and username like '%{$_REQUEST['username']}%'";
			$fpage="&username={$_REQUEST['username']}";
		}		
		$countsql="select count(*) from administrator where 1=1 $fsql";
		$pagesql="select * from administrator where 1=1 $fsql order by id desc  ";
		$bottom="?action=list{$fpage}";
		//数据分页，见page函数定义
		$datasql=page($countsql,$pagesql,$bottom,15);
		echo "<form name='delform' id='delform' action='?action=alldel' method='post'>
		<table style='width:100%;' align='center'>";
		if($datasql){
			echo "<tr class='tr_top'><td>账号</td><td>姓名</td><td>年龄</td><td>性别</td><td>管理</td></tr>";
			while($rs=fetch($datasql[1])){
				echo "<tr class='tr_mid' align='center'>
				  <td>{$rs['username']}</td>
				  <td>{$rs['realname']}</td>
				  <td>{$rs['age']}</td>
				  <td>{$rs['gender']}</td>
				  <td>		  
				  <a href='?action=insert&id={$rs['id']}'>编辑</a> 
				  &nbsp; &nbsp;<a href='javascript:ask(\"?action=alldel&id={$rs['id']}\")'>删除</a>
				  </td>
				  </tr>";
			}
		}
		echo "</table></form>";
	break;
}
include_once("admin_foot.php");
?>