<?php
session_start();
include_once('include/db.php');
checkadmin();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link href="images/inc.css?v1" rel="stylesheet" />
<script src="include/jquery-1.3.2.min.js"></script>
<script src="include/function.js"></script>
<body>
