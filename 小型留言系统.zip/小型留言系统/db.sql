-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2020-05-25 22:28:56
-- 服务器版本： 5.7.26
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `liuyan`
--

-- --------------------------------------------------------

--
-- 表的结构 `administrator`
--

CREATE TABLE `administrator` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(64) NOT NULL,
  `realname` varchar(255) DEFAULT NULL COMMENT '姓名',
  `age` varchar(3) DEFAULT NULL,
  `gender` varchar(12) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `administrator`
--

INSERT INTO `administrator` (`id`, `username`, `password`, `realname`, `age`, `gender`) VALUES
(21, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '风清扬', '22', '男');

-- --------------------------------------------------------

--
-- 表的结构 `messagebook`
--

CREATE TABLE `messagebook` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `reply` text COMMENT '回复',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未审核',
  `ptime` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `messagebook`
--

INSERT INTO `messagebook` (`id`, `title`, `nickname`, `content`, `reply`, `status`, `ptime`) VALUES
(55, '尘嚣喧扰', '沉寂', '采撷一串串的梦，学校的嬉戏，回想起是那么绚丽；而成长的追逐，竟已一跃而过。', '世间的尘嚣喧扰，似乎沉寂，但愿我们不忘过往。', 1, 1590416564),
(54, '熟悉的地方', '郁郁葱葱', '校园的树郁郁葱葱，教室里洒满清澈的阳光。熟悉的地方，熟悉的人，心中难免惆怅。', '相信青春不老，你我会重逢在美好的未来。', 1, 1590416506),
(53, '无法释怀', '火焰', '初恋像柠檬，虽酸却耐人寻味；热恋像火焰，虽热却不能自拔；失恋像伤疤，虽痛却无法释怀。', '所以我们要懂得呵护爱情！', 1, 1590416433);

--
-- 转储表的索引
--

--
-- 表的索引 `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `messagebook`
--
ALTER TABLE `messagebook`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `administrator`
--
ALTER TABLE `administrator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- 使用表AUTO_INCREMENT `messagebook`
--
ALTER TABLE `messagebook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
