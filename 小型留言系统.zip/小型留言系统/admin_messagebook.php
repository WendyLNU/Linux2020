<?php
include_once("admin_head.php");
checkadmin();
$action=isset($_GET['action'])?$_GET['action']:"list";
switch($action){
	case "insert": 
		$Arr=array();
		if(isset($_GET['id'])&&$_GET['id']){
			$id=intval($_GET['id']);
			$Arr=getone("select * from messagebook where id='$id'");
			$Arr=fromTableInForm($Arr);
		}
		setFormSource();
		?>
		<form action='?action=save&id=<?php echo  $id?>' method='post'  onsubmit='return check()' class='myform' style='width:500px;margin-top:20px;'> 
		 <input type="radio" name='status' value=1 <?php if($Arr['status']==1) echo "checked"; ?>/>显示  &nbsp;&nbsp;&nbsp;&nbsp;
         <input type="radio" name='status'  value=0  <?php if($Arr['status']==0) echo "checked"; ?>/>隐藏<br />
         <textarea name='reply' style='width:430px;height:120px; margin-top:30px;' placeholder='回复此留言'><?php echo $Arr['reply'] ?></textarea><br>
		 <center><input type='submit' class='submit' value='保存'></center>
		</form>
		<?php
	break;
	
	case "save":
		checkFormSource();
		$_POST=escapeArr($_POST);
 		if(isset($_GET['id'])&&$_GET['id']){
			$id=intval($_GET['id']);
            update("messagebook",$_POST," id=$id"); 
		}
		alert("操作成功！","?action=list");
	break;
	 
	case "alldel":
		$key=isset($_POST["allidd"])&&$_POST["allidd"]?$_POST["allidd"]:array(intval($_GET['id']));
		for($i=0;$i<count($key);$i++){ 
			if(!$find) query("delete from  messagebook  where id={$key[$i]}");
		}
		alert('成功删除'.count($key).'条信息！','?action=list');
	break;
	   
	case "list":
		echo "<form action='?action=list' method='post'>
		<input type='text' placeholder='请输入标题'  style='height:30px;margin-left:0;' value='{$_REQUEST['title']}' name='title'>
		<input type='submit'  value='搜索'></form>";    
		$fsql=$fpage="";	
		if(isset($_REQUEST['title'])&&$_REQUEST['title']){
			$fsql.=" and title like '%{$_REQUEST['title']}%'";
			$fpage.="&title={$_REQUEST['title']}";
		}
		$countsql="select count(*) from messagebook where 1=1 $fsql";
		$pagesql="select * from messagebook where 1=1 $fsql order by id desc";
		$bottom="?action=list{$fpage}";
	 
		$datasql=page($countsql,$pagesql,$bottom,15);
		echo "<form name='delform' id='delform' action='?action=alldel' method='post'>
		<table style='width:100%;' align='center'>";
		if($datasql){
		echo "<tr class='tr_top'><td>留言标题</td><td>内容</td><td>回复</td><td>时间</td><td>审核</td><td>管理</td></tr>";
		while($rs=fetch($datasql[1])){
			echo "<tr class='tr_mid'>
			  <td align='left'><input type=checkbox value='{$rs['id']}'  name='allidd[]' id='allidd'>{$rs['title']}</td>	
			  <td align='left'>{$rs['content']}</td>	
			  <td align='left'>{$rs['reply']}</td>
			  <td align='center'>".date2("Y-m-d H:i:s",$rs['ptime'])."</td>
			  <td align='center'>";echo $rs['status']==1?"✔":"✘"; echo"</td>	 	 
			  <td align='center'>
			  <a href='?action=insert&id={$rs['id']}'>编辑</a>  &nbsp; &nbsp;
			  <a href='javascript:ask(\"?action=alldel&id={$rs['id']}\")'>删除</a>
			  </td>
			  </tr>";		  
		}
		echo "<tr><td colspan=7 align='right'>
					 <div style='width:280px;float:left'>{$datasql['pl']}{$datasql['pldelete']}</div>
					 <div  style='float:right'>{$datasql[2]}</div>
					 <div style='clear:both;'></div>
			  </td></tr>";
		}
		echo "</table></form>";
	break;
}
include_once("admin_foot.php");
?>