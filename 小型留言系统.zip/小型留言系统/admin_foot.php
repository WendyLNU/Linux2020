  </section>
  <div style="clear:both"></div>
</section>
</body>
</html>
<?php 
 close();
?>