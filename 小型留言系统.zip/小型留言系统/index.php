<?php
ob_start();
include_once('include/db.php');
include_once("head.html");
$action=isset($_GET['action'])?$_GET['action']:"list";
switch($action){	
	case "list":
		$countsql="select count(*) from  messagebook where status=1 ";
		$pagesql="select * from  messagebook where status=1 order by id desc";
		$bottom="?action=list{$fpage}";
		$datasql=page($countsql,$pagesql,$bottom,15);
		?>
        <style>
		.t1{background-color:#55a6dd;height:50px;padding-left:30px;font-weight:bold; color:#FFF; text-align:left; line-height:50px;border-radius:20px 20px 0 0;}
		.t2{background-color:#f0f0f0;min-height:90px; padding:30px;margin-bottom:30px;border-radius:0 0 20px 20px;}
        </style>
        <div style='width:800px;min-height:400px;float:left;'>
        <div  id='gggg'>
        <?php
		if($datasql){
			
			while($rs=fetch($datasql[1])){
				?>
				  <div class='t1'>
                      <?php echo $rs['title']?> &nbsp; &nbsp; 【  <?php echo$rs['nickname']?> / <?php echo date2("Y-m-d H:i:s",$rs['ptime'])?>  】
                  </div>
				  <div class='t2'>
                   留言内容：<?php 
				   echo $rs['content'];
				   if($rs['reply']){
					   ?>
                       <div style="margin-top:20px;color:#005e9e;">管理回复：<?php echo $rs['reply']?></div>
                       <?php
				   }
				   ?>
                  
                  </div>
			<?php
            }
			?>
            </div>
				
					 <?php echo $datasql[2]?>

		<?php
        }
		setFormSource();
		?>
        </div>
        
		<script>
		function check(){
			if(!$('input[name=title]').val()){alert('标题不能为空');$('input[name=title]').focus();return false;}
			if(!$('input[name=nickname]').val()){alert('昵称不能为空');$('input[name=nickname]').focus();return false;}
			if(!$('textarea[name=content]').val()){alert('留言内容不能为空');$('textarea[name=content]').focus();return false;}
			return true;
		}
		function ajaxTo(){
			post("ajax.php",$('#bd').serialize());
		}
		</script>	
		<div style='width:350px;float:right;'>
		<form class='myform' id='bd'  method='post' >
		<input placeholder='留言标题' name='title' style='width:280px;'><br><br>
		<input placeholder='您的昵称' name='nickname' style='width:280px;' value=''><br><br>
		<textarea placeholder='留言内容' name='content' style="width:280px;height:60px;"></textarea><br><br>
		<input type='button'  onclick="if(check())ajaxTo()" value='提交留言' class='submit'>
		<input type='button'  onclick='window.open("admin_login.html")' value='管理留言' class='submit'>
		</form>
		</div>
        <div id='jquerydiv'></div>
		<?php
	 break;
}
include_once("foot.html");
?>
