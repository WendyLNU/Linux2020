<?php
/*对javascript的alert()函数用div进行模拟，不阻塞浏览器进程，体验度好*/
function alert($msg,$url='index.php'){
	if($msg){
		echo "<div  class='popmsg' style='padding:0px;border:1px solid #DADADA;margin:100px auto;width:80%'>
		  <div style='padding:6px;font-size:12px;border-bottom:1px solid #DADADA;'><b>提示信息！</b></div>
		  <div style='height:130px;font-size:10pt;background:#ffffff'><br />
			<div align='center'>$msg</div>
			<div align='center' id='jumptime' style='margin:20px 0px;font-size:20px;font-weight:bold'>5</div>
			<div style='margin-top:20px;' align='center'><a href='$url' style='color:#000000'>如果你的浏览器没反应，请点击这里...</a></div>
		  </div>
		</div>";
	   echo "<script>$().ready(function(){Jump('$url','$msg');})</script>";
	}
	else{
		echo "<script>location='$url'</script>";
	}
	die();
}

/*判断管理员是否登录，如果否则跳转到admin.php*/
function checkadmin($action='show'){
	global $A;
	$A=@getone("select * from administrator where username='{$_SESSION['adminname']}' and password='{$_SESSION['adminpassword']}'");
	if(!$A['id']){
		if($action=='show'){
		   $_SESSION['adminname']="";
		   $_SESSION['adminpassword']="";
		   unset($_SESSION['adminname'],$_SESSION['adminpassword']);
		   echo "<script>location='admin_login.php'</script>";
		   die("No permission");
		}
		else return false;
	}
	return true;
}

/*分页函数*/
function page($countsql,$pagesql,$url,$bottomsql,$num=8){
	$str="";
	$page=isset($_GET['page'])?(intval($_GET['page'])>0?intval($_GET['page']):1):1;
    $count=getone($countsql);
	$total=$count['count(*)'];	 
	if($total){
		$total_page=ceil($total/$num);
		$page=($page>$total_page)?$total_page:$page;
		$offset=($page-1)*$num;
		$returns[1]=query($pagesql." limit $offset,$num");
		//
		$str.=" <div class='ex_page_link'>&nbsp;<a href='{$url}&page=1'><span class='ex_page_bottm'><center>首页</center></span></a>";
		$tempshang=$page-1;$tempxia=$page+1;
		if($page!=1) $str.="&nbsp;<a href='{$url}&page={$tempshang}'><span class='ex_page_bottm'><center>上页</center></span></a>";
		for($i=1;$i<=$total_page;$i++)
		   if($page==$i) $str.="&nbsp;<a href='{$url}&page={$i}'><span class='ex_page_bottm ex_page_sec' style='width:30px;' ><center>{$i}</center></span></a>";
		   else  if($i-$page>=-$num&&$i-$page<=$num) $str.="&nbsp;<a href='{$url}&page={$i}'><span class='ex_page_bottm' style='width:30px;' ><center>{$i}</center></span></a>";
		if($page!=$total_page)  $str.="&nbsp;<a href='{$url}&page={$tempxia}'><span class='ex_page_bottm'><center>下页</center></span></a>";
		$str.=" 
		&nbsp;<span  class='ex_page_bottm'><center><a href='{$url}&page={$total_page}'>尾页</a></center></span>
		&nbsp;<span  class='ex_page_bottm' ><center>{$page}/{$total_page}</center></span></div>";
		$returns[2]=$str;
		//
		$returns['pl']="<span class='op'> &nbsp; </span>
		<span class='op' onclick=\"SelectAll('selectAll','delform','allidd')\">全选/</span>
		<span class='op' onclick=\"SelectAll('','delform','allidd')\">反选/</span>
		<span class='op' onclick=\"SelectAll('selectNo','delform','allidd')\">不选</span>";
		$returns['pldelete']="<span class='op2' onclick=\"if(checkdelform('delform','allidd')&&confirm('您真的要删除这些内容吗？')) delform.submit()\">批量删除</span>";
		return $returns;
	}
	else return false;	
}

/***********************时间处理系列函数自定义，解决2038年的问题***************************
/*                                                                                  *
/*                                                                                  */
/*返回时间戳格式*/
function strtotime2($timestring=""){
	if(class_exists("DateTime")){     
		@date_default_timezone_set("Asia/ShangHai");
		if($timestring)$temp=new DateTime($timestring);
		else           $temp=new DateTime();
		return $temp->format("U");
	}
	else return strtotime($timestring);
}

/*返回字符串时间格式*/
function date2($format="Y-m-d H:i:s",$timemap=""){
	if(class_exists("DateTime")){ 
		@date_default_timezone_set("Asia/ShangHai");		
		$timemap=($timemap=="")?strtotime2():$timemap;//无时间戳，则当前时间
		$temp=new DateTime("@".$timemap);
		$temp->setTimezone(new DateTimeZone("PRC"));  //PRC  Asia/ShangHai
		return $temp->format($format);	
	}
	else{
		return $timemap?date($format,intval($timemap)):date($format);
	}
}

/*返回当前时间戳*/
function time2(){
	return strtotime2();
}
/***********************************end**********************************************/



/********************************安全相关函数******************************************
/*                                                                                   *
/*                                                                                   */
/*
安全性处理，如果魔术引号未开启，则强行使用addslashes函数进行过滤;
*/		
function escape($str){
	if(!get_magic_quotes_gpc()){
		return addslashes($str);//防止sql注入
	}
	else return $str; 
}

/*以数组为参数，调用上面的escape()函数，目的是简化代码*/	
function escapeArr($Arr){
	foreach($Arr as $key=>$value){
		$Arr[$key]=escape($value);
	}
	return $Arr;
}
/*检查表单来源，禁止重复提交：设置来源*/
function setFormSource(){
	if(!isset($_COOKIE["post_data_flag"])){
		setcookie("post_data_flag","1",time()+3600*8);
	}	
}
/*检查表单来源，禁止重复提交：检查来源*/
function checkFormSource(){
	if(isset($_COOKIE["post_data_flag"])){
		setcookie("post_data_flag","",time()-10000);
	}else{
		die("来源不合法");
	}
	
}
/*判断两个参数是否相等，如果想到则返回 selected  主要用在select表单中用于自动选中某个option*/
function select($a,$b){
	if($a==$b)return " selected";
}

/*从数据库读取信息填充到表单里，通常如果信息中包含引号会造成各种问题，这个函数就是对单双引号就行转码*/	
function fromTableInForm($rs){
	foreach($rs as $key=>$value)$rs[$key]=str_replace(array("'","\""),array("&#39;","&#34;"),$value);
	return $rs;
}
/********************************end************************************************/




/********************************数据库相关操作******************************************
/*                                                                                    *
/*                                                                                   */
//对mysqli_close进行封装，目的是为今后的扩展预留数据库接口，如更换数据库或服务器环境发生变化*
function close(){
	global $conn;
	mysqli_close($conn);
}
/*对mysqli_query进行封装，目的是为今后的扩展预留数据库接口，如更换数据库或服务器环境发生变化*/
function query($sql){
	global $conn;
	return mysqli_query($conn,$sql);
}
/*对mysqli_fetch_assoc进行封装，目的是为今后的扩展预留数据库接口，如更换数据库或服务器环境发生变化*/
function fetch($rs){
	return mysqli_fetch_assoc($rs);
}
/*新增数据*/
function insert($table,$array,$keyArr=array()){  
	foreach($array as $key=>$value){
		if(count($keyArr)>0){
			if(in_array($key,$keyArr)) $str.=" `$key`='$value',";
		}
		else{
			$str.=" `$key`='$value',";
		}
	}
	$str=substr($str,0,strrpos($str,','));
	$sql="insert into `$table` set $str ";
	if(query($sql))return true;else {echo "<b>ERR_SQL:$sql</b><br>";die();}
}
/*更新数据*/
function update($table,$array,$where,$keyArr=array()){   
	foreach($array as $key=>$value){	
		if(count($keyArr)>0){
			if(in_array($key,$keyArr)) $str.=" `$key`='$value',";
		}
		else{
			$str.=" `$key`='$value',";
		}
	}
	$str=substr($str,0,strrpos($str,','));
	$sql="update `$table` set $str where $where";
	if(query($sql))return true;
	else {echo "<b>ERR_SQL:$sql</b><br>";die();}  
} 

/*取出一条*/
function getone($query){
	return fetch(query($query));
}
/**********************************************************************************/
?>