<?php
//连接参数配置 
$conn = new mysqli('localhost','liuyan','liuyan','liuyan');
if (mysqli_connect_errno()) {
	printf("Connect failed: %s\n", mysqli_connect_error());
	exit();
}	
mysqli_set_charset($conn,"utf8");	
//系统环境设置//
error_reporting(E_ALL & ~E_NOTICE);        //不显示NOTICE提示
date_default_timezone_set("Asia/ShangHai");//设置时区
//载入函数并连接数据库
include_once(dirname(__FILE__)."/function.php");
$A=array();//管理员全局变量
if(isset($_SESSION['adminname'])&&$_SESSION['adminname'])  checkadmin();
?>