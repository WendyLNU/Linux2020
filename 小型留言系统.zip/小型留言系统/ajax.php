<?php
ob_start();
include_once('include/db.php');	
$_POST=escapeArr($_POST);
$_POST['ptime']=time2();
$_POST['status']=1;
if($_POST['title']&&insert("messagebook",$_POST)){
	echo "
	<script>
	$('input[name=title]').val('');
	$('input[name=nickname]').val('');
	$('textarea[name=content]').val('');
	$('#gggg').append('<div class=\"t1\">{$_POST['title']} 【 {$_POST['nickname']} /".date2()."】</div><div class=\"t2\">{$_POST['content']}</div>'); 
	</script>";
}
?>