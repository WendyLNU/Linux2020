<?php
session_start();
include_once('include/db.php');
if($A['id']){
	$_SESSION['adminname']="";
	$_SESSION['adminpassword']="";
	unset($_SESSION['adminname'],$_SESSION['adminpassword']);
}
echo "<script>location='admin_login.html'</script>";
?>