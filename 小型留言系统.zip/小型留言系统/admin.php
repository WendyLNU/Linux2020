<?php
session_start();
include_once('include/db.php');
checkadmin();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link href="images/inc.css?v2" rel="stylesheet" />
<title>访客在线留言板后台管理</title>
<script src="include/jquery-1.3.2.min.js"></script>
<script src="include/function.js"></script>
</head>
<body>
<div class="con">
<div class="menu">
	<li><a href='admin_administrator.php?action=list' target="mainframe">账号管理</a></li>
	<li><a href='admin_messagebook.php?action=list' target="mainframe">留言管理</a></li>
	<li><a href="javascript:void(0);" onClick="if(confirm('您真的要退出吗？'))location='admin_logOut.php';">退出登录</a></li>
	<li><a href='index.php' target="_blank">前台首页</a></li>
</div>
<iframe id='mainframe' class='mainframe' name='mainframe'  frameborder="0" scrolling="yes" src="<?php if($A['id'])echo" admin_administrator.php";?>"></iframe>
</div>
</body>
</html>
<?php close();?>