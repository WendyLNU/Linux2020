<?php
session_start();
include_once('include/db.php');
$_POST=escapeArr($_POST);
$row=getone("select * from administrator where username='{$_POST['username']}' and password='".md5($_POST['password'])."'");
if($row['id']){
   $_SESSION['adminname']=$row['username'];
   $_SESSION['adminpassword']=$row['password'];	  
   echo "<script>location='admin.php'</script>"; 
   die();
}
else{
	?>
    <!DOCTYPE html>
    <html>
    <head>
    <meta charset="utf-8" />
    <link href="images/inc.css?v3" rel="stylesheet" />
    <script src="include/jquery-1.3.2.min.js"></script>
    <script src="include/function.js"></script>
    <body>
    <?php
   alert('账号错误','admin_login.html');
}
?>