package com.gyf.dao;

import com.gyf.pojo.OrderItem;

public interface OrderItemDao {

    public int saveOrderItem(OrderItem orderItem);

}
