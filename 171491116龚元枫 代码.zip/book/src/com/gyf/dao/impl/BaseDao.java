package com.gyf.dao.impl;

import com.gyf.utils.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public abstract class BaseDao {
    private QueryRunner queryRunner = new QueryRunner();

    /**
     * @param sql
     * @param objs
     * @return 如果update成功，返回影响的数据条数，如果失败，返回-1
     */
    public int update(String sql, Object... objs) {
        Connection connection = JdbcUtils.getConnection();
        try {
            return queryRunner.update(connection, sql, objs);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    /**
     * 查询返回一条数据的语句
     *
     * @param type
     * @param sql
     * @param objs
     * @param <T>
     * @return
     */
    public <T> T queryForOne(Class<T> type, String sql, Object... objs) {
        Connection connection = JdbcUtils.getConnection();
        try {
            return queryRunner.query(connection, sql, new BeanHandler<T>(type), objs);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    /**
     * 查询返回多条数据的语句
     * @param type
     * @param sql
     * @param objs
     * @param <T>
     * @return
     */
    public <T> List<T> queryForList(Class<T> type, String sql, Object... objs) {
        Connection connection = JdbcUtils.getConnection();
        try {
            return (List<T>) queryRunner.query(connection, sql, new BeanListHandler<>(type), objs);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    /**
     * 执行返回一行一列的sql语句
     * @param sql
     * @param objs
     * @return
     */
    public Object queryForSingleValue(String sql,Object...objs){
        Connection connection = JdbcUtils.getConnection();
        try {
            return queryRunner.query(connection,sql,new ScalarHandler(),objs);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
}
