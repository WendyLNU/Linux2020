package com.gyf.dao;

import com.gyf.pojo.Order;

public interface OrderDao {
    public int saveOrder(Order order);
}
