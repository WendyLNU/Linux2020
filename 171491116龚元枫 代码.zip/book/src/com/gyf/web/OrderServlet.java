package com.gyf.web;

import com.gyf.pojo.Cart;
import com.gyf.pojo.User;
import com.gyf.service.OrderService;
import com.gyf.service.impl.OrderserviceImpl;
import com.gyf.utils.JdbcUtils;
import jdk.nashorn.internal.scripts.JD;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class OrderServlet extends BaseServlet {
    private OrderService orderService = new OrderserviceImpl();
    /**
     * 生成订单
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void createOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //先获取cart和userID
        Cart cart = (Cart)req.getSession().getAttribute("cart");


        User user = (User)req.getSession().getAttribute("user");

        if(null == user){
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req,resp);
            return;
        }


        //生成订单
        String orderId = orderService.createOrder(cart, user.getId());

//        req.setAttribute("orderId",orderId);
        //这里应该使用重定向
        req.getSession().setAttribute("orderId",orderId);
        resp.sendRedirect(req.getContextPath()+"/pages/cart/checkout.jsp");
        //请求转发到
        //req.getRequestDispatcher("/pages/cart/checkout.jsp").forward(req, resp);
    }
}
