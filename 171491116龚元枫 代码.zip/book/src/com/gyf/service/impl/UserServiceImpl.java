package com.gyf.service.impl;

import com.gyf.dao.impl.UserDaoImpl;
import com.gyf.pojo.User;
import com.gyf.service.UserService;

public class UserServiceImpl implements UserService {
    private UserDaoImpl userDao = new UserDaoImpl();
    @Override
    public void registUser(User user) {
        userDao.saveUser(user);
    }

    @Override
    public User login(User user) {
        return userDao.queryUserByUsernameAndPassword(user.getUsername(),user.getPassword());
    }

    /**
     *
     * @param username
     * @return 返回false表示用户不存在
     */
    @Override
    public boolean existsUsername(String username) {
        if(userDao.queryUserByUsername(username)==null){
            return false;
        }else{
            return true;
        }
    }
}
