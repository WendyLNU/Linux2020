package com.gyf.test;

import com.gyf.pojo.Cart;
import com.gyf.pojo.CartItem;
import com.gyf.service.OrderService;
import com.gyf.service.impl.OrderserviceImpl;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class OrderServiceTest {

    @Test
    public void createOrder() {
        Cart cart = new Cart();

        cart.addItem(new CartItem(1, "java", 1, new BigDecimal(100), new BigDecimal(100)));
        cart.addItem(new CartItem(1, "java", 1,new BigDecimal(100) , new BigDecimal(100)));
        cart.addItem(new CartItem(2, "cpp", 1, new BigDecimal(100), new BigDecimal(100)));

        OrderService orderService = new OrderserviceImpl();

        System.out.println("订单号是:"+orderService.createOrder(cart, 1));
    }
}