package com.gyf.test;

import com.gyf.pojo.User;
import com.gyf.service.UserService;
import com.gyf.service.impl.UserServiceImpl;
import org.junit.Test;

import javax.jws.soap.SOAPBinding;

import static org.junit.Assert.*;

public class UserServiceImplTest {
    UserService userService = new UserServiceImpl();
    @Test
    public void registUser() {
        userService.registUser(new User(null,"admin2","admin2","admin@163.com"));
    }

    @Test
    public void login() {
        System.out.println(userService.login(new User(null,"admin","admin1",null)));
    }

    @Test
    public void existsUsername() {
        System.out.println(userService.existsUsername("admin"));
    }
}