package com.gyf.test;

import com.gyf.pojo.Cart;
import com.gyf.pojo.CartItem;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class CartTest {

    @Test
    public void addItem() {
        Cart cart = new Cart();
        cart.addItem(new CartItem(1, "java", 1, new BigDecimal(100), new BigDecimal(100)));
        cart.addItem(new CartItem(1, "java", 1,new BigDecimal(100) , new BigDecimal(100)));
        cart.addItem(new CartItem(2, "cpp", 1, new BigDecimal(100), new BigDecimal(100)));
        System.out.println(cart);
    }


    @Test
    public void deleteItem() {
        Cart cart = new Cart();
        cart.addItem(new CartItem(1, "java", 1, new BigDecimal(100), new BigDecimal(100)));
        cart.addItem(new CartItem(1, "java", 1,new BigDecimal(100) , new BigDecimal(100)));
        cart.addItem(new CartItem(2, "cpp", 1, new BigDecimal(100), new BigDecimal(100)));
        cart.deleteItem(1);
        System.out.println(cart);
    }

    @Test
    public void clear() {
        Cart cart = new Cart();
        cart.addItem(new CartItem(1, "java", 1, new BigDecimal(100), new BigDecimal(100)));
        cart.addItem(new CartItem(1, "java", 1,new BigDecimal(100) , new BigDecimal(100)));
        cart.addItem(new CartItem(2, "cpp", 1, new BigDecimal(100), new BigDecimal(100)));
        cart.clear();
        System.out.println(cart);
    }

    @Test
    public void updateCount() {
        Cart cart = new Cart();
        cart.addItem(new CartItem(1, "java", 1, new BigDecimal(100), new BigDecimal(100)));
        cart.addItem(new CartItem(1, "java", 1,new BigDecimal(100) , new BigDecimal(100)));
        cart.addItem(new CartItem(2, "cpp", 1, new BigDecimal(100), new BigDecimal(100)));
        cart.clear();
        cart.addItem(new CartItem(1, "java", 1, new BigDecimal(100), new BigDecimal(100)));
        cart.updateCount(1, 10);
        System.out.println(cart);
    }
}