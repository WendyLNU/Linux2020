package com.gyf.test;

import com.gyf.dao.impl.BaseDao;
import com.gyf.pojo.Book;
import com.gyf.service.BookService;
import com.gyf.service.impl.BookServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class BookServiceTest {
    BookService bookService = new BookServiceImpl();

    @Test
    public void addBook() {
        bookService.addBook(new Book(null, "我爱java", "gyf", new BigDecimal(9999), 9999, 0, null));
    }

    @Test
    public void deleteBookById() {
        bookService.deleteBookById(22);
    }

    @Test
    public void updateBook() {
        bookService.updateBook(new Book(23, "我不爱java", "gyf", new BigDecimal(9999), 9999, 0, null));
    }

    @Test
    public void queryBookById() {
        System.out.println(bookService.queryBookById(23));
    }

    @Test
    public void queryBooks() {
        for (Book book : bookService.queryBooks()) {
            System.out.println(book);
        }
    }

    @Test
    public void page() {
        for(Book book:bookService.page(1, 4).getItems()){
            System.out.println(book);
        }
    }

    @Test
    public void pageByPrice() {
        for(Book book:bookService.pageByPrice(1, 4,10,50).getItems()){
            System.out.println(book);
        }
    }
}