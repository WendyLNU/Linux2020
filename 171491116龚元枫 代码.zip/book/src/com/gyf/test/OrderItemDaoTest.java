package com.gyf.test;

import com.gyf.dao.OrderDao;
import com.gyf.dao.OrderItemDao;
import com.gyf.dao.impl.OrderItemDaoImpl;
import com.gyf.pojo.OrderItem;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class OrderItemDaoTest {

    @Test
    public void saveOrderItem() {
        OrderItemDao orderItemDao = new OrderItemDaoImpl();

        orderItemDao.saveOrderItem(new OrderItem(null, "php", 1,
                new BigDecimal(100), new BigDecimal(100), "1"));
        orderItemDao.saveOrderItem(new OrderItem(null, "py", 1,
                new BigDecimal(100), new BigDecimal(100), "1"));
    }
}