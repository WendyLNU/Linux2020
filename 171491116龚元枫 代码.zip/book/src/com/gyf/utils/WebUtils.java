package com.gyf.utils;

import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

public class WebUtils {
    /**
     * 用map降低了耦合
     * @param value
     * @param bean
     */
    public static <T> T copyParamToBean(Map value, T bean){
        try {
            BeanUtils.populate(bean,value);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return bean;
    }

    /**
     * 将字符串转化成int
     * @param strInt
     * @return
     */
    public static int parseInt(String strInt,Integer defaltValue){
        try {
            int i = Integer.parseInt(strInt);
            return i;
        } catch (NumberFormatException e) {
            return defaltValue;
        }

    }
}
