package com.gyf.utils;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.alibaba.druid.pool.DruidPooledConnection;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.util.zip.CheckedOutputStream;

public class JdbcUtils {
    private static DruidDataSource dataSource;
    private static ThreadLocal<Connection> conns = new ThreadLocal<Connection>();
    static{

        try {
            Properties properties = new Properties();
            //读取配置文件
            InputStream is = JdbcUtils.class.getClassLoader().getResourceAsStream("jdbc.properties");
            //从流中加载数据
            properties.load(is);
            //创建了数据库连接池
            dataSource = (DruidDataSource) DruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取数据库连接池中的连接
     * @return  返回null则获取连接失败
     */
    public static Connection getConnection(){//太尼玛秀了
        Connection conn = conns.get();
        if(null==conn){
            try {
                conn = dataSource.getConnection();//从数据库连接池获取连接
                //没有的话就获得一个连接，以后就用这个连接
                conns.set(conn);
                conn.setAutoCommit(false);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return conn;
    }

    /**
     * 提交事务并且关闭释放连接
     */
    public static void commitAndClose(){
        Connection conn = conns.get();
        if(null!=conn){//说明之前操作过
            try {
                conn.commit();//提交事务
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }
        //用完之后必须用这个，或则回出错(因为tomcat的底层使用了线程池)
        conns.remove();
    }

    /**
     * 提交事务，并关闭释放连接
     */
    public static void rollbackAndClose(){
        Connection conn = conns.get();
        if(null!=conn){//说明之前操作过
            try {
                conn.rollback();//回滚事务
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }
        //用完之后必须用这个，或则回出错(因为tomcat的底层使用了线程池)
        conns.remove();
    }

    /**
     * 关闭连接，放回数据库连接池
     * @param connection
     */
//    public static void close(Connection connection){
//        if(null!=connection){
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//    }
}
