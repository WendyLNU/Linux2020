/*
Navicat MySQL Data Transfer

Source Server         : lp
Source Server Version : 50090
Source Host           : localhost:3306
Source Database       : boostore

Target Server Type    : MYSQL
Target Server Version : 50090
File Encoding         : 65001

Date: 2020-06-18 18:08:52
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `administrator`
-- ----------------------------
DROP TABLE IF EXISTS `administrator`;
CREATE TABLE `administrator` (
  `apassword` char(255) NOT NULL,
  `aname` char(255) NOT NULL,
  `aid` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of administrator
-- ----------------------------

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `uaddress` text,
  `gwc` set('') default NULL,
  `upassword` char(255) NOT NULL,
  `uname` char(255) NOT NULL,
  `uid` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (null, null, '123456', 'lp', '1');
INSERT INTO `customer` VALUES (null, null, '13456', 'jxk', '2');
INSERT INTO `customer` VALUES (null, null, '123456', 'lsk', '3');

-- ----------------------------
-- Table structure for `merchandise`
-- ----------------------------
DROP TABLE IF EXISTS `merchandise`;
CREATE TABLE `merchandise` (
  `msmallclass` char(255) default NULL,
  `mbigclass` char(255) NOT NULL,
  `mname` char(255) NOT NULL,
  `mprice` float NOT NULL,
  `bid` int(11) NOT NULL,
  `mid` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`mid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of merchandise
-- ----------------------------

-- ----------------------------
-- Table structure for `merchant`
-- ----------------------------
DROP TABLE IF EXISTS `merchant`;
CREATE TABLE `merchant` (
  `password` char(255) NOT NULL,
  `bname` char(255) NOT NULL,
  `bid` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of merchant
-- ----------------------------
