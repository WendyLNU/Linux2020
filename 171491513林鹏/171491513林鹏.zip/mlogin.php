<html>
    <head>
      <meta charset="utf-8">
      <title>一切的开始</title>
  
    </head>
    
    <body style="background-image: url('./picture/1.jpeg');background-size:100% 100%;background-repeat:no-repeat;">
        <form  method="get" action="mverify.php" name="login" onsubmit="return check();">
        
        <table style="position: absolute;left:55%;top:35%;" cellspacing="25px">
        <tr><td>账号：</td><td><input type="text" name="account"></td><td><p id="inaccount" style="color: red;"></p></td></tr>
        <tr><td>密码：</td><td><input type="password" name="password"></td><td><p id="inpassword" style="color: red;"></p></td></tr>
        <tr><td colspan="2" align="center"><input type="submit" value="登录"/></td></tr>
        </table>
     
        </form>
    </body> 
    
</html>
<script>
function check(){
  document.getElementById("inaccount").innerHTML="";
  document.getElementById("inpassword").innerHTML="";
  if(document.forms["login"]["account"].value==""){
    document.getElementById("inaccount").innerHTML="* 请输入账号!";
    return false;
  }
  
    if(document.forms["login"]["password"].value==""){
    document.getElementById("inpassword").innerHTML="* 请输入密码!";
    return false;
    }
      return true;
  
}
</script>