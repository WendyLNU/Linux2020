<html>
<head>
<meta charset="utf-8">
<title>林荫书舍</title>
</head>
<body style="background-color: #BBFFFF;">
<table align="center" cellspacing="0" width="100%">
<div style="background-color: #66FFFF;height:50px;width:100%;position:absolute;top:0px;left:0px">
<img src="picture/logo.png" height="50px" width="100px" style="position: absolute;left:30%">

<?php 
require "conn.php";


if(empty($_GET["uname"])){
    echo "<p style='position: absolute;left:80%'><a href='login.php'>登录</a>|<a href='signin.php'>注册</a></p>";
    $uname=null;
}else{
    $uname=$_GET["uname"];
    echo "<p style='position: absolute;left:80%'>用户:".$_GET["uname"].". 您好！ |<a href=center.php?uname=".$uname.">个人中心</a>|<a href='linyinshushe.php'>退出</a></p>";
    
}
echo "</div>";

$myquery=mysql_query("select count(*) from merchandise",$db);
$row=mysql_fetch_array($myquery);
$num_cnt=$row[0];

$page_size=20;
$page_cnt=ceil($num_cnt/$page_size);

if(isset($_GET["page"]))
$page=$_GET["page"];
else
$page=1;

$query_start=($page-1)*$page_size;
$querysql="select * from merchandise limit $query_start,$page_size";

$queryset=mysql_query($querysql);
{echo "<table width='1000' border='1' cellspacing='0' align='center'> style='position:absolute;top:100px;'";


      
      $j=0;
        while($row=mysql_fetch_array($queryset))
        {
            if($j%4==0){
                echo "<tr>";
            }
           echo "<td style='width:250px;'><a href=gwc.php?uname=".$uname."&mid=".$row["mid"]."><img src='".$row["mpicture"]."' height='300px' width='245px'><p align='center'>书名：".$row["mname"]."</p></a><p align='center'>".$row["mbigclass"]."</p></td>";
           $j++;
            if($j%4==0){
            echo "</tr>";
        }
        }
       
      
echo "<tr><td align='center' colspan='4' bgcolor='#CCFF00'>";
for($i=1;$i<=$page_cnt;$i++){
echo "<a href=linyinshushe.php?page=".$i.">".$i."</a>&nbsp";
}
echo "</td></tr>";
echo "</table>";}
?>

</tr>

</table>
</body>

</html>