<?php
$bname=$_GET["bname"];
$mname=$_POST["mname"];
$mbigclass=$_POST["mbigclass"];
$mprice=$_POST["mprice"];
$mnumber=$_POST["mnumber"];

$allowedExts = array("gif", "jpeg", "jpg", "png");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);     // 获取文件后缀名
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 2048000)   // 小于 200 kb
&& in_array($extension, $allowedExts))
{
    if ($_FILES["file"]["error"] > 0)
    {
        echo "<script> alert('错误：: " . $_FILES["file"]["error"] . "')</script>";
    }
    else
    {
        if (file_exists("upload/" . $_FILES["file"]["name"]))
        {
            echo "<script> alert('文件名重复!') </script>";
        }
        else
        {
            // 如果 upload 目录不存在该文件则将文件上传到 upload 目录下
            move_uploaded_file($_FILES["file"]["tmp_name"], "upload/" . $_FILES["file"]["name"]);
            include("conn.php");
            $result=mysql_query("select bid from merchant where bname='$bname'");
            while($row=mysql_fetch_array($result))
        {
         $bid=$row[0];
        }
            $mpicture="upload/".$_FILES["file"]["name"];
            $rs=mysql_query("insert into merchandise (mname,mbigclass,mprice,mnumber,mpicture,bid) values ('$mname','$mbigclass','$mprice','$mnumber','$mpicture','$bid')");
            if($rs){
                echo "<h2 aligen='center'>添加成功！</h2>       <a href='shangpinguanli.php'>返回</a> ";
                
            }
        }
    }
}
else
{
    echo "<script> alert('文件格式错误!') </script>";
}

?>