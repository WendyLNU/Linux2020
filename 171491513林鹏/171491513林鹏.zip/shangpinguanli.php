<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>
<?php $mname=$_GET["mname"] ?>
<body>

<div style="width: 100%;height:50px;background-color:greenyellow;position:absolute;left:0px;top:0px;right:0px;">
<input type="button" style="border:none;position:absolute;left:25%;top:10px;font-size:20px;background-color:greenyellow" value="添加商品" onclick="return add()">
<input type="button" style="border:none;position:absolute;left:65%;top:10px;font-size:20px;background-color:greenyellow" value="现有商品" onclick="return now()">
</div>
<div id="add" style="width: 100%;height:550px">
<form name="adds" <?php echo "action='addm.php?bname=".$mname."'"?>  method="post" onsubmit="return check()" enctype="multipart/form-data">  
    <table cellspacing="20px" style="position: absolute;top:20%;left:25%">
        <tr><td>商品名：</td><td><input type="text" name="mname" id="mname"></td><td><p id="inmname" style="color: red;"></p></td></tr>
        <tr><td>商品数量：</td><td><input type="number" name="mnumber" id="mnumber"></td><td><p id="inmnumber" style="color: red;"></p></td></tr>
        <tr><td>商品种类：</td><td><select name="mbigclass" size="1">
        <?php
        
        include("conn.php");
        $result=mysql_query("select * from classtable",$db);
        while($row=mysql_fetch_array($result))
        {
         echo "<option values=".$row["class"].">".$row["class"]."</option>";
        }
        ?>
        </select></td></tr>
        <tr><td>商品价格：</td><td><input type="number" name="mprice" id="mprice"></td><td><p id="inmprice" style="color: red;"></p></td></tr>
        <tr><td><label for="file">商品图片：</label></td><td><input type="file" name="file" id="file"></td><td><p id="inpicture" style="color: red;"></p></td></tr>
        <tr><td colspan="2" align="right"><input type="submit" value="提交" style="border: none;background-color:greenyellow"></td></tr>
    </table>
</form>
</div>
</body>
</html>
<script>
    function check(){
        document.getElementById("inmname").innerHTML="";
        document.getElementById("inmnumber").innerHTML="";
        document.getElementById("inmprice").innerHTML="";
        document.getElementById("inpicture").innerHTML="";
  if(document.forms["adds"]["mname"].value==""){
    document.getElementById("inmname").innerHTML="* 请输入商品名!";
    return false;
  }
  
    if(document.forms["adds"]["mnumber"].value==""){
    document.getElementById("inmnumber").innerHTML="* 请输入数量!";
    return false;
    }
    if(document.forms["adds"]["mprice"].value==""){
    document.getElementById("inmprice").innerHTML="* 请输入价格!";
    return false;
  }
  if(document.forms["adds"]["picture"].value==""){
    document.getElementById("inpicture").innerHTML="* 请提交图片!";
    return false;
  }
      return true;
    }
</script>