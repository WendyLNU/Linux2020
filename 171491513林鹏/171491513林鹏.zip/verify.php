<?php
$account=$_GET["account"];
$password=$_GET["password"];

//echo "<script> alert('".$password."'); </script>";

include("conn.php");
$result=mysql_query("select upassword from customer where uname='$account'",$db);
$row=mysql_fetch_object($result);
if($row->upassword != ""){
    
    if($password.trim()==$row->upassword.trim()){
        echo "<script> window.location.href='linyinshushe.php?uname=".$account."'; </script>";
    }else{
        echo "<script> alert('密码错误！'); </script>";
    }
}else
{
    echo "<script> alert('账号错误！'); window.location.href='login.php'; </script>";
    
}


?>