<html>
    <head>
      <meta charset="utf-8">
      <title>一切的开始</title>
  
    </head>
    
    <body style="background-image: url('./picture/1.jpeg');background-size:100% 100%;background-repeat:no-repeat;">
        <form  methond="get" action="enroll.php" name="login" onsubmit="return check();">
        
        <table style="position: absolute;left:55%;top:35%;" cellspacing="25px">
        <tr><td>账号：</td><td><input type="text" name="account" placeholder="在此输入用户名"></td><td><p id="inaccount" style="color: red;"></p></td></tr>
        <tr><td>密码：</td><td><input type="password" name="password" placeholder="在此输入密码"></td><td><p id="inpassword" style="color: red;"></p></td></tr>
        <tr><td>确认密码：</td><td><input type="password" name="repassword" placeholder="再次输入密码"></td><td><p id="inrepassword" style="color: red;"></p></td></tr>
        <tr><td colspan="2" align="right"><input type="submit" value="注册" onsubmit=""></td></tr>
        </table>
     
        </form>
    </body> 
    
</html>
<script>
function check(){
  document.getElementById("inaccount").innerHTML="";
  document.getElementById("inpassword").innerHTML="";
  document.getElementById("inrepassword").innerHTML="";
  if(document.forms["login"]["account"].value==""){
    document.getElementById("inaccount").innerHTML="* 请输入账号!";
    return false;
  }
  
    if(document.forms["login"]["password"].value==""){
    document.getElementById("inpassword").innerHTML="* 请输入密码!";
    return false;
    }
    if(document.forms["login"]["password"].value!=document.forms["login"]["repassword"].value){
    document.getElementById("inrepassword").innerHTML="* 两次密码不一致!";
    return false;
    }
      return true;
  
}
</Script>