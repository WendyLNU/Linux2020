<html>
    <head>
        <meta charset="utf-8">
    </head>
<?php 
$db=mysql_connect('localhost','root','123456') or die("与本地端MySQL服务器连接失败！");
mysql_query('set names utf8',$db);
mysql_select_db('boostore',$db)or die("连接失败");

?>
</html>