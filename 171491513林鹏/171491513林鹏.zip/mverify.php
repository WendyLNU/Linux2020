<?php
$account=$_GET["account"];
$password=$_GET["password"];

//echo "<script> alert('".$password."'); </script>";

include("conn.php");
$result=mysql_query("select password from merchant where bname='$account'",$db);
$row=mysql_fetch_object($result);
if($row->password != ""){
    
    if($password==$row->password){
        echo "<script> window.location.href='shanghu.php?mname=".$account."'; </script>";
    }else{
        echo "<script> alert('密码错误！'); </script>";
    }
}else
{
    echo "<script> alert('账号错误！'); window.location.href='mlogin.php'; </script>";
    
}


?>