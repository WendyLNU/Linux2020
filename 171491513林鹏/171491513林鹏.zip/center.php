<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <?php
    $uname=$_GET["uname"];
    include("conn.php");
    $result=mysql_query("select * from customer where uname='$uname'",$db);
    while($row=mysql_fetch_array($result)){
        $uid=$row["uid"];
    }

    $rs=mysql_query("select mid from gwc where uid='$uid'",$db);
    echo "<table align='center'>";
    while($ro=mysql_fetch_array($rs)){
        $mid=$ro["mid"];
        $r=mysql_query("select * from merchandise where mid='$mid'",$db);
        while($r=mysql_fetch_array($r)){
            echo "<tr><td><img src='".$r["mpicture"]."' height='50px' width='35px'></td><td>书名：".$r["mname"]."</td><td>价格：".$r["mprice"]."￥</td><td><a href='gwc.php?uname=".$uname."&mid=".$r["mid"]."'>购买</a></td></tr>";
        }
    }
    echo "</table>";

    ?>
</body>
</html>