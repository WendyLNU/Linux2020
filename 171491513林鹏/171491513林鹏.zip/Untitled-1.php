<html>
    <head>
        <meta charset="utf-8">
    </head>
<?php
        
        include("conn.php");
        $result=mysql_query("select * from classtable",$db);
        while($row=mysql_fetch_array($result))
        {
         echo $row[0];
        }
        ?>
        </html>