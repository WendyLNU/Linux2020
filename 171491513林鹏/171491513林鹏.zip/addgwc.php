<?php
$uid=$_GET["uid"];
$mid=$_GET["mid"];
$number=$_GET["number"];
$uname=$_GET["uname"];

include("conn.php");

$result=mysql_query("insert into gwc(uid,mid,number) values ('$uid','$mid','$number')",$db);
if($result){
    echo "<script> alert('加入成功！'); window.location.href='linyinshushe.php?uname=".$uname."';</script>";
}else{
    echo "<script> alert('此商品已在购物车！')</script>";
}
?>