<?php

$uname=$_GET["account"];
$upassword=$_GET["password"];

//echo "<script> alert('".$uname."') </script>";

include("conn.php");

$result=mysql_query("select uname from customer where uname='$uname'",$db);
$row=mysql_fetch_object($result);
if($row->uname != ""){
    echo "<script> alert('该账号已存在！'); window.location.href='signin.php'; </script>";
}else{
$sql="insert into customer(uname,upassword) values ('$uname','$upassword')";
if(mysql_query($sql,$db)){
    echo "<script> alert('成功！'); window.location.href='login.php'; </script>";
}

}
?>