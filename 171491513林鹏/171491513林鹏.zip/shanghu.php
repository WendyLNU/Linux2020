<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>林荫书舍商户</title>
</head>

<body style="background-color: maroon;">
<div style="background-color: white;height:50px;width:100%;position:absolute;top:0px;left:0px">
<img src="picture/logo.png" height="50px" width="100px" style="position: absolute;left:30%">
<?php
   echo "<p style='position: absolute;left:80%'>商户:".$_GET["mname"]." 您好！|<a href='linyinshushe.php'>退出</a></p>";
?>
</div>
<div style="background-color:#66FFFF;height:300px;width:125px;position:absolute;left:30%;top:50px;">
<input type="button" style="border:none;position:absolute;left:5%;top:10px;font-size:25px;background-color:#66FFFF" value="商品管理" onclick="return guanli()">
<input type="button" style="border:none;position:absolute;left:5%;top:55px;font-size:25px;background-color:#66FFFF" value="交易记录" onclick="return jilu()">
</div>
<div id="son" style="background-color:blue;height:600px;width:800px;position:absolute;left:40%;top:50px">

</div>
</body>
</html>
<script>
    function guanli(){
        var a=location.search;
        var b=a.indexOf("=");
        var c=a.length;
        var d=a.slice(b+1,c);
        document.getElementById("son").innerHTML="<iframe src='shangpinguanli.php?mname="+d+"' width='100%' height='100%'></iframe>";
    }
</script>