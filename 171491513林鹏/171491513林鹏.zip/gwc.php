<html>
<head>
<meta charset="utf-8">
</head>


<body style="background-color: #BBFFFF;">
<div style="background-color: #66FFFF;height:50px;width:100%;position:absolute;top:0px;left:0px">
<img src="picture/logo.png" height="50px" width="100px" style="position: absolute;left:30%">

<?php 
require "conn.php";
$uname=$_GET['uname'];
$mid=$_GET["mid"];



if(empty($_GET["uname"])){
    echo "<script> alert('请登录！');  window.location.href='login.php'; </script>";
}else{
    echo "<p style='position: absolute;left:80%'>用户:".$_GET["uname"].". 您好！ |<a href='linyinshushe.php'>退出</a></p>";
    $uname=$_GET["uname"];
}

echo "</div> <form action='buy.php' methond='post' onsubmit='return check()'>";

include("conn.php");



$result=mysql_query("select * from merchandise where mid='$mid'",$db);
while($row=mysql_fetch_array($result)){
    echo "<table style='position:absolute;top:50px;left:40%;width=280px'><tr><td colspan='4'><img src='".$row["mpicture"]."' height='350px' width='280px'></td><td></td></tr>";
    echo "<tr><td align='right' width='25%'>书名：</td><td width='210px' colspan='3' align='center'>".$row["mname"]."</td></tr>";
    echo "<tr><td align='right' width='25%'>价格：</td><td width='210px' colspan='3' align='center'>".$row["mprice"]."</td></tr>";
    echo "<tr><td align='right' width='25%'>数量：</td>";
    echo "<td width='70px' align='right'><input type='button' value='-' style='border:none;background-color:#BBFFFF;color:red;font-size:20px;' onclick='return zijian()'></td>";
    echo "<td width='70px' align='center'><input type='number' id='number' name='number' value='1' style='width=35px;'></td>";
    echo "<td width='70px' align='left'><input type='button' value='+' style='border:none;background-color:#BBFFFF;color:red;font-size:20px;' onclick='return zijia()'>";
    echo  "</td></tr>";
    echo "<tr><td></td><td></td><td><input type='button' value='立即购买' style='border:none;background-color:#BBFFFF;' onclick='return buy()'></td></tr>";
    echo "<tr><td></td><td></td><td><input type='button' value='加入购物车' style='border:none;background-color:#BBFFFF;' onclick='return addgwc()'></td></tr>";

    echo "<tr><td> <input type='number' id='price' value='".$row['mprice']."' hidden> </td></tr>";
    echo "<tr><td> <input type='number' id='mid' value='".$row['mid']."' hidden> </td></tr>";
}
$rs=mysql_query("select uid from customer where uname='$uname'",$db);
while($ro=mysql_fetch_array($rs)){
    echo "<tr><td> <input type='number' id='uid' value='".$ro['uid']."' hidden> </td></tr></table>";
    echo "<tr><td> <input type='text' id='uname' value='".$uname."' hidden> </td></tr>";
}
?>

</form>

</html>
<script> 
    function zijia(){
        
        var i=Number(document.getElementById("number").value);
        document.getElementById("number").value=i+1;
        
    }
    function zijian(){
        
        var i=Number(document.getElementById("number").value);
        if(i==1){
            document.getElementById("number").value=i;
        }else{
        document.getElementById("number").value=i-1;
        }
    }
    function buy(){
        var i=Number(document.getElementById("number").value);
        var j=Number(document.getElementById("price").value);
          alert("请支付"+i*j+"元");
    }
    function addgwc(){
        var i=Number(document.getElementById("mid").value);
        var j=Number(document.getElementById("uid").value);
        var k=Number(document.getElementById("number").value);
        var z=String(document.getElementById("uname").value);
        window.location.href="addgwc.php?uid="+j+"&mid="+i+"&number="+k+"&uname="+z;
    }
</script>