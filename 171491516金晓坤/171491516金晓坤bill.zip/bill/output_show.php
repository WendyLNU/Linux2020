<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>支出</title>

</head>
<?PHP $nid = $_GET["nid"]; ?>
<body topmargin="0" leftmargin="0">	
	<form action="input_save.php?nid=<?PHP echo $nid; ?>" method="post" target="_top" onsubmit="return CheckForm();">
	<div id="input"  style=" height:530px; width:100%; background-color:#CCCC00; border:1px solid #000000;">
	
		<!-- 金额 -->
		<div id="money" style="height:20%; width:100%; background-color:#FFFF00;">
			<input id="mon" name="mon" type="text" size="50" maxlength="50" style="height:100%; width:100%; font-size:50px; color:#0033CC;" placeholder="0.00"  />
		</div>
		
		<!--类型 -->
		<div id="class" style="height:10%; width:100%; background-color:#CCCCCC;">
			<div style="width:10%; height:100%; background-color:#FFFF33; float:left;">
				<div style="height:20%; width:100%;"></div>
				<div style="height:60%; width:100%; font-size:24px;">支出</div>
				<div style="height:20%; width:100%;"></div>
			</div>
			<div style="width:90%; height:100%; background-color:#FFCC66; float:left;">
				<select name="province" id="province" style="height:100%; width:10%;"></select>
				<select name="city" id="city"  style="height:100%; width:10%;"></select>		
			</div>
		</div>
		
		<!-- 时间 -->
		<div id="date" style="height:10%; width:100%; background-color:#CCFFCC;">
			<div style="width:10%; height:100%; background-color:#CC9933; float:left;">
				<div style="height:20%; width:100%;"></div>
				<div style="height:60%; width:100%; font-size:24px;">时间</div>
				<div style="height:20%; width:100%;"></div>
			</div>
			<div style="width:90%; height:100%; background-color:#FF66CC; float:left;">
				<input name="date" id="date" type="text" style="height:100%; width:100%;" value="<?PHP date_default_timezone_set('prc'); 
					echo date('y-m-d  h:i:sa',time());?>" readonly="true">
			</div>
		</div>
		
		<!--��ע -->
		<div id="date" style="height:50%; width:100%; background-color:#99FFCC;">
			<div style="width:10%; height:100%; background-color:#FF0099; float:left;">
				<div style="height:20%; width:100%;"></div>
				<div style="height:60%; width:100%; font-size:24px;">备注</div>
				<div style="height:20%; width:100%;"></div>
			</div>
			<div style="width:90%; height:100%; background-color:#CCCCCC; float:left;">
			<textarea name="content" cols="" rows="" style="height:99%; width:99%;"></textarea>
			</div>

		</div>
	
		<div id="sub" align="center" style="height:9%; width:100%; padding-top:1%;">
			<input name="sub" type="submit" value="保存"  style="height:90%; width:30%;"/>
		</div>	
	
	</div>
	</form>
</body>
</html>
<script type="text/javascript" src="jquery-3.5.1.min.js"></script>
<script type="text/javascript">
	function CheckForm(){
		var mon = document.getElementById("mon");
		if(mon.value.trim() == ""){
			mon.value = "0.0";
		}
		
		var sel = document.getElementById("province");
		var sel2 = document.getElementById("city");
		
		if(sel2.value.trim() == ""){
			sel2.value = "";
		}
	}
	window.onload = function(){
		createProvinces();
		
		province.onchange= createCities;
		
		}
	
		var provinces=['未分类','支出֧'];
		var cities=[
			['无分类'],
			['饮食','酒水','水果','旅游','化妆品','学习','其他']
		];
		var province = document.getElementById("province");
		
		var city = document.getElementById("city");
		
		function createProvinces(){
			for(var i in provinces){
				var op = new Option(provinces[i],provinces[i]);
				province.options.add(op);
			
			}
		}
		
		
		function createCities(){
		
			var index=province.selectedIndex;
			
			city.options.length = 0;
			
			for(var i in cities[index]){
				var op = new Option(cities[index][i],cities[index][i]);
				city.options.add(op);
			}
		
		}
		

</script>