<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>display</title>

<link href="net_div.css" rel="stylesheet" type="text/css" />
</head>

		<?php 
			include("conn.php");
			$nid = $_GET["nid"];
			$cla = $_GET["cla"];
		?>
<body topmargin="0" leftmargin="0" background="images/net_right.jpg">

		<?php
			$sql = "SELECT * FROM nets where id='$nid' and class='$cla'";
			$result = mysql_query($sql,$db) OR die (mysql_error($db));
			while($row = mysql_fetch_array($result)){
		?>
			
				<div class="box1" style="text-align:center; background-image:url(images/div.jpg);">
					<a href="<?PHP echo $row["address"];?>" target="_blank">
						<?PHP echo $row["cont"]; ?>
					</a>
				</div>
	
	 <?PHP 
		 }
		 mysql_free_result($result);
		 mysql_close($db);	
	 ?>
				<div class="box1" style="text-align:center; background-image:url(images/div2.png);">
					<a href="add_net.php?nid=<?PHP echo $nid; ?>&cla=<?PHP echo $cla; ?>" target="_top">
						添加
					</a><br>
					<a href="del_net.php?nid=<?PHP echo $nid; ?>&cla=<?PHP echo $cla; ?>" target="_top">
						删除
					</a>
				</div>	 
</body>
</html>
