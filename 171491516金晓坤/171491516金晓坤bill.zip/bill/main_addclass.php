<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>添加类别</title>
<link href="main_top.css" rel="stylesheet" type="text/css" />
</head>

<body background="images/note.jpg">
<div>
		<?PHP include("main_top.php"); ?>
<center>	
	<div style="border:solid 2px #999999; height:300px; width:300px; margin-top:20px;">

		<?PHP $nid = $_GET["nid"]; ?>
		<form action="main_addclass_save.php?nid=<?PHP echo $nid;?>" method="post" onsubmit="return CheckForm();">
		<div style="text-align:center;">
			<h2 align="center" style="border-bottom:2px double #666666; line-height:60px;">添加类别</h2>
		<div>
		
		<table width="300" border="0" cellspacing="0" cellpadding="2" align="center">
		  <tr>
			<td height="84" colspan="2"><input name="class" id="class" type="text" size="30" maxlength="30"/></td>
		  </tr>
		  
		  <tr align="center">
			<td height="48"><input name="sub" type="submit" value="保存" /></td>
			<td><input name="clo" type="button" value="取消" onclick="history.back();"/></td>
		  </tr>
		</table>
		</form>
	</div>
</center>
</div>
</body>
</html>

<script type="text/javascript">
	function CheckForm(){
		var c = document.getElementById("class");
			if(c.value.trim() == ""){
			alert("类别名不能为空");
			return false;
		}
	}
</script>