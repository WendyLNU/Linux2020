<?PHP  
	$no = $_GET["no"];
	$nid = $_GET["nid"];
	$title = $_POST["cap"];
	$date = $_POST["time"];
	$content = $_POST["content"];
	$class = $_POST["sel"];

	include("conn.php");

	$sql="UPDATE notes SET class='$class',title='$title',content='$content' WHERE no={$no} and id={$nid}";

	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	mysql_close($db);
	
	echo "<script>{location.href='note.php?nid=$nid&class=$class'} </script>";
		

?>