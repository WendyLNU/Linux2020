<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>网址管理</title>
<script type="text/javascript" src="jquery-3.5.1.min.js"></script>
<script type="text/javascript">
      window.onload = function() {
          getHeight();//得到屏幕高度
       };
       function getHeight() {
             var net = document.getElementById('net');//得到 net div
             var body_height = document.documentElement.clientHeight;//document.body.clientHeight����<!DOCTYPE html>�����»᷵��0
			 var body_width = document.documentElement.clientWidth;
             net.style.height = body_height + 'px';
			 net.style.width = body_width + 'px';
			// alert(body_height);
         }

</script>
<link href="net.css" rel="stylesheet" type="text/css" />
</head>
<body background="">
	<div id="net" class="net">
		<?php 
			include("conn.php");
			$nid = $_GET["nid"];
		$sql = "SELECT * FROM user where id = '$nid'";
		$result = mysql_query($sql,$db) OR die (mysql_error($db));
		$row = mysql_fetch_array($result);
		?>
	
		<div class="top">
			<div class="top_log">
				<img src="images/log.png" style=" height:100%; width:100%;"/>
			</div>
			<div class="top_info">
				<div class="top_info_id"><font class="top_font"><?PHP echo $row["user"]."(".$row["name"].")"; ?></font></div>
				<div><font class="top_font"><a href="updateinfo.php?nid=<?PHP echo $nid; ?>" target="_self">修改</a></font></div>
				<div style="margin-top:5px; color:"><a href="main.php?nid=<?PHP echo $nid; ?>" target="_top">返回主菜单</a></div>
			</div>
			<div class="top_help">
				<div class="top_o">
					<font class="top_font">
						<a href="feedback.php" target="_blank">反馈</a> &nbsp;|&nbsp;
						<a href="help.php" target="_blank">帮助中心</a> &nbsp;|&nbsp;
						<a href="log_top.php" target="_top">退出</a>
					</font>
				</div>
				<div class="top_search">
					<form action="#" method="post" name="search" target="_blank" style="width:50px;">
						<input name="key" type="text" size="30" maxlength="30" placeholder="请在此处输入查找内容" />
					</form>
				</div>
			</div>
		</div>
		<div class="left" style="background-image:url(images/net_left.png);">
			<div class="opts">
				<?php
					$sql = "SELECT * FROM net_class where id='$nid'";
					$result = mysql_query($sql,$db) OR die (mysql_error($db));
					while($row = mysql_fetch_array($result)){
				?>
				
				<div class="opt" style="text-align:center;">
					<a href="net_div.php?nid=<?PHP echo $nid;?>&cla=<?PHP echo $row["class"]; ?>" target="my_iframe">
						<?PHP echo $row["class"];?>
					</a>			 
				</div>
				
				 <?PHP 
					 }
				  	mysql_free_result($result);
					mysql_close($db);	
				 ?>

			</div>
			<div class="add" >
				分类管理<br>
				<a href="main_addclass.php?nid=<?PHP echo $nid; ?>" target="_self">添加</a>
					 |
				<a href="main_delclass.php?nid=<?PHP echo $nid; ?>" target="_self"> 删除</a>
			</div>
		</div>
		
		<div class="right">

			
			<iframe name="my_iframe" id="my_iframe" src="images/net_right.jpg" frameborder="0" width="100%" height="100%" scrolling="no">
				
			</iframe>
		</div>
	</div>
</body>
</html>
