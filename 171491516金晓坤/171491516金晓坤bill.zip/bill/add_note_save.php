<?PHP  
	$nid = $_GET["nid"];
	$title = $_POST["cap"];
	$date = $_POST["time"];
	$content = $_POST["content"];
	$class = $_POST["sel"];

	include("conn.php");

	$sql="insert into notes(id,class,date,title,content) values({$nid},'$class','$date','$title','$content')";
					
	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	mysql_close($db);
	
	echo "<script>{location.href='note.php?nid=$nid&class=$class';} </script>";
		

?>