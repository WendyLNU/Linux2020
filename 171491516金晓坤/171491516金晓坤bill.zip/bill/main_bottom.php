		<div id="bottom" align="center">
			<a href="contect.php" target="_blank">联系我们</a>&nbsp;|&nbsp;<a href="help.php" target="_blank">帮助中心</a>
		</div>