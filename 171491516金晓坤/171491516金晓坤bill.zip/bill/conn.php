<?php
$db = @mysql_connect('localhost','root','jxk19980402') or die("连接失败21");
@mysql_query("set names 'utf-8'",$db);//设置编码方式

//是否连接失败
@mysql_select_db('individual',$db) or die("连接失败");
?>