<?PHP 
			include("conn.php");
			$no = $_GET["no"];
			
			//得到记录
			$sql1 = "SELECT * FROM notes where no={$no}";
			$result = mysql_query($sql1,$db) OR die (mysql_error($db));
			$row = mysql_fetch_array($result);
			
			//得到id 和类别
			$nid = $row["id"];
			$class = $row["class"];

			//删除
			$sql = "Delete FROM notes where no={$no}";
			$result = mysql_query($sql,$db) OR die (mysql_error($db));
			
			mysql_close($db);
			
			//返回
			echo "<script>{location.href='note.php?nid=$nid&class=$class'} </script>";
 ?>