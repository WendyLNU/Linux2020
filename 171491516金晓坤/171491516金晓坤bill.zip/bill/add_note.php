<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>添加笔记</title>

<link href="add_note.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery-3.5.1.min.js"></script>
<script type="text/javascript">


  $(document).ready(function () {
 
        window.onload = function () {
             getHeight();
        };
        function getHeight() {
             var net = document.getElementById('add');
             var body_height = document.documentElement.clientHeight;
			 var body_width = document.documentElement.clientWidth;
             net.style.height = body_height + 'px';
			 net.style.width = body_width + 'px';
         }
		 

    });
	

</script>

</head>
		
<body>
		<?php 
			include("conn.php");
			$nid = $_GET["nid"];
			$class = $_GET["class"];
		?>
	<form action="add_note_save.php?nid=<?PHP echo $nid; ?>" target="_top" method="post" onsubmit="return CheckForm();">

	<div id="add">
		<div id="head">
			<div style="width:50%; float:left; margin-top:10px;" align="left">
				<a href="note.php?nid=<?PHP echo $nid; ?>&class=<?PHP echo $class;?>" target="_top">
					<input name="close" type="button" value="返回" style="width:30%;" />
				</a>
			</div>
			
			<div style="width:50%; float:left; margin-top:10px;" align="right">
			<input name="sub" type="submit" value="保存" style="width:30%;"/>
			</div>
		</div>
		<div id="title">
			<div style="height:75%; width:100%; background-color:#CCCCCC;">
				<input id="cap" name="cap" type="text" size="50" maxlength="50" style="height:90%; width:100%; font-size:24px;" placeholder="标题"/>
			</div>
			<div style="height:25%; width:100%; background-color:#FFFF00;">
				<div style="width:40%; height:100%; float:left; background-color:#FFFFFF;">
					<select id="sel" name="sel" style="width:50%; height:100%;">

					<?PHP
					$sql = "SELECT * FROM notes_class where id='$nid'";
					
					$result = mysql_query($sql,$db) OR die (mysql_error($db));
					while($row = mysql_fetch_array($result)){
						if($row["name"] == "全部笔记")continue;
					?>
						<option <?PHP if($row["name"]==$class) echo "selected='selected'"; ?>>
							<?PHP echo $row["name"]; ?>
						</option>
					 <?PHP 
					 }
				  	mysql_free_result($result);
					mysql_close($db);	
					 ?>
					</select>
				</div>
				<div style="width:60%; height:100%; float:left;" align="center">
					<input id="time" name="time" type="text" 
						value="<?PHP date_default_timezone_set('prc'); echo date('y-m-d  h:i:sa',time());?>"
					    size="50" maxlength="50" style="height:100%; width=100%; "/>
					
				</div>
			</div>
		</div>
		<div id="body">
			<textarea id="content" name="content" cols="" rows="50" style="height:100%; width:100%;"></textarea>
		</div>
	</div>

	</form>
</body>
</html>

<script type="text/javascript">
	
	function CheckForm(){
	
		/*
		var time = document.getElementById("time");
		alert(time.value);
		*/
		
		var cap = document.getElementById("cap");
		if(cap.value.trim()==""){
			cap.value = "无标题";
		}
		
		/*
		var content = document.getElementById("content");
		alert(content.value);
		
		var content = document.getElementById("sel");
		alert(content.value);
		*/
		return true;
	}

</script>