<form action="#" method="post" name="search" target="_blank" style="width:50px">
	<input name="key" type="text" size="30" maxlength="30" />
</form>