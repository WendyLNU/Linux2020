<?PHP 
	$dno = $_GET["del_no"];
	$did = $_GET["nid"];
	
	include("conn.php");
	$sql = "SELECT * FROM net_class where id={$did} and no={$dno}";
	
	//连接数据库
	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	$row = mysql_fetch_array($result);
	$result = NULL;
	
	//得到类型名
	$cla = $row["class"];
	
	//删除类别
	$sql_del1 = "Delete FROM net_class where id={$did} and no={$dno}";
	$result = mysql_query($sql_del1,$db) OR die (mysql_error($db));
	$result = NULL;
	
	//删除类别对应记录
	$sql_del2 = "Delete FROM nets where id={$did} and class ='$cla'";
	$result = mysql_query($sql_del2,$db) OR die (mysql_error($db));
	
	mysql_free_result($result);
	mysql_close($db);	
	
	//跳转
	echo "<script>{document.location.href='main_delclass.php?nid=$did'}</script>";
	
	

 ?>