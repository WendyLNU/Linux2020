<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>笔记管理</title>

<link href="note.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery-3.5.1.min.js"></script>
<script type="text/javascript">


  $(document).ready(function () {
 
        window.onload = function () {
             getHeight();
        };
        function getHeight() {
             var net = document.getElementById('note');
             var body_height = document.documentElement.clientHeight;
			 var body_width = document.documentElement.clientWidth;
             net.style.height = body_height + 'px';
			 net.style.width = body_width + 'px';
         }
    });

</script>

						<?php 
						include("conn.php");
						$nid = $_GET["nid"];
						//检查分类中是否有全部笔记，没有则插入
						$sql = "SELECT * FROM notes_class where name='全部笔记' and id='$nid'";
						$result = mysql_query($sql,$db) OR die (mysql_error($db));
						if(!$row = mysql_fetch_array($result)){
							$sql = "insert into notes_class(id,name) values({$nid},'全部笔记')";
							$result1 = mysql_query($sql,$db) OR die (mysql_error($db));
							
							
						}
						?>
<script type="text/javascript">
	$(document).ready(function (){
		$("#sel").change(function(){
			//得选择框中的选择
			var opt = $("#sel").val();
			
			//假如选择的是 “添加分类”则转向添加分类页面，不然转向当前页面
			if(opt == "添加分类"){
				location.href = "note_add_class.php?nid=<?PHP echo  $nid; ?>"
			}else{
				var str = "note.php?nid=<?PHP echo $nid; ?>&class="+opt;
				location.href=str;
			}
		});
		
	});
	
</script>

</head>
<body>
	<center>
		<div id="note" style="background-color:#999999;">
		
			<!-- 左侧 -->
			<div id="note_left">
				
				<div class="top" align="left";>
					<div style="width:50%; height:100%; float:left;">
				
					<select id="sel" class="sel" name="allNote" size="1" style="width:60%; height:100%; margin-top:0; font-size:20px;">
						<?PHP
							$sql = "SELECT * FROM notes_class where id='$nid'";
							$result = mysql_query($sql,$db) OR die (mysql_error($db));
							
							//是否有已选择的分类
							$class=isset($_GET["class"])?$_GET["class"] : "全部笔记";
							while($row = mysql_fetch_array($result)){
						?>
						
						<option <?PHP if($row["name"]==$class) echo "selected='selected'"; ?>>
							<?PHP echo $row['name']; ?>
						</option>
					
						 <?PHP 
							 }
							mysql_free_result($result);
							mysql_close($db);	
						 ?>
						 
						<option>
							添加分类
						</option>
					</select>
					</div>
					
					<!-- 头部设计 -->
					<div style="width:50%; height:100%; float:left;">
						<div style="height:60%; width:100%;"></div>
						<div style="height:40%; width:100%;" align="right">
							<a href="main.php?nid=<?PHP echo $nid; ?>" target="_self" style="font-size:18px;">返回主菜单</a>
						</div>
					</div>
				
				</div>
				
				<!-- 搜索  -->
				<div class="mid" align="left" >
					<input type="text" placeholder="请输入搜索内容" style="width:100%; height:100%; ">
				</div>
				
				<!-- 展示笔记 -->
				<div class="body">
					<?php 
					include("conn.php");
					$nid = $_GET["nid"];
					
					$sql = "SELECT * FROM notes where id='$nid'";
					
					$class=isset($_GET["class"])?$_GET["class"] : "全部笔记";
					if($class!='全部笔记'){
						$sql = $sql." and class='$class'";
					}
					
					$result = mysql_query($sql,$db) OR die (mysql_error($db));
					while($row = mysql_fetch_array($result)){
					?>
						<a href="show_note.php?nid=<?PHP echo $nid; ?>&note_no=<?PHP echo $row["no"]; ?>" target="note_iframe">
							<div class="note"><?PHP echo substr($row["content"],0,40)."..."; ?></div>
						</a>	
					 <?PHP 
					 }
				  	mysql_free_result($result);
					mysql_close($db);	
					 ?>
					
					<!-- 添加记录-->
					<a href="add_note.php?nid=<?PHP echo $nid; ?>&class=<?PHP echo $class; ?>" target="note_iframe">	
						<div class="add_note">	
							+	
						</div>
					</a>
					
				
				</div>
			</div>
			
			<!-- 右侧界面 -->
			<div id="note_right">
				<iframe name="note_iframe" id="note_iframe" src="images/frame.jpeg.jpg" frameborder="1" width="100%" height="100%" scrolling="no">
			</div>
		</div>
	</center>
</body>
</html>
