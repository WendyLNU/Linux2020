<?PHP 
	$u = $_POST["user"];
	$n = $_POST["username"];
	$p = $_POST["pas"];


	include("conn.php");
	
	$sql1 = "SELECT * FROM user where user = '$u'";
	$result = mysql_query($sql1,$db) OR die (mysql_error($db));
	$row = mysql_fetch_array($result);
	
	//检查账号是否已使用过
	if($row){
	echo 1111111111;
		$mes = "用户已被注册";
		 echo "<script>{location.href='register.php?mes=$mes'} </script>";
	}

	
	$sql = "insert into user(name,user,password) values('$n','$u','$p')";
	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	$row = mysql_fetch_array($result);

	//返回注册成功信息

	$mes = "注册成功！请登录";
	echo "<script>{location.href='log_top.php?mes=$mes&u=$u'} </script>";

  	
?>