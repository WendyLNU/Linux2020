<?PHP 
	$u = $_POST["user1"];
	$p = $_POST["pas"];

	include("conn.php");
	
	$sql = "SELECT * FROM user where user = '$u'";
	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	$row = mysql_fetch_array($result);
	
	//检查是否存在该用户
	if(!$row){
		$mes = "不存在该用户";
		 echo "<script>{location.href='log_top.php?mes=$mes'} </script>";
	}
	

	//检查密码
	if($row["password"] != $p){
		$mes = "用户名或者密码错误";
		echo "<script>{location.href='log_top.php?mes=$mes&u=$u'} </script>";
	}
	
	//检查通过
	$i = $row["id"];
	echo "<script>{location.href='main.php?nid=$i'} </script>";
  	
?>