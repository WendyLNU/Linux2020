		<div class="body">
			<div class="ad_man" style="background-image:url(images/net.png); background-repeat:no-repeat;">
				<font size="+2" color="#000000"><a href="net.php?nid=<?PHP echo $nid; ?>" target="_self">网址管理</a></font>
			</div>
			<div class="bill_man" style="background-image:url(images/bill.jpg); background-repeat:no-repeat;">
				<font size="+2" color="#000000"><a href="bill.php?nid=<?PHP echo $nid; ?>" target="_self">账单管理</a></font>
			</div>
			<div class="note_man" style="background-image:url(images/note.png); background-repeat:no-repeat;">
				<font size="+2" color="#000000"><a href="note.php?nid=<?PHP echo $nid; ?>" target="_self">笔记管理</a></font>			
			</div>

		</div>