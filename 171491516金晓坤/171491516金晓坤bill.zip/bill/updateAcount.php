<?PHP  
	$n = $_POST["username"];
	$p = $_POST["pas"];
	$nid = 

	include("conn.php");

	$sql="UPDATE user SET name='$n',password='$p' WHERE id={$nid}";

	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	mysql_close($db);
	
	echo "<script>{location.href='main.php?nid=$nid'} </script>";
		

?>