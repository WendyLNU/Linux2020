	<?PHP 
		include("conn.php");
		$nid = $_GET["nid"];		
		$sql = "SELECT * FROM user where id = '$nid'";
		$result = mysql_query($sql,$db) OR die (mysql_error($db));
		
		$row = mysql_fetch_array($result);
		$u = $row["user"];
		$n = $row["name"];
	 ?>


		<div class="top">
			<div class="top_log">
				<img src="images/log.png" height="100" />
			</div>
			<div class="top_info">
				<div class="top_info_id"><font class="top_font"><?PHP echo $u."(".$n.")"; ?></font></div>
				<div><font class="top_font"><a href="updateinfo.php?nid=<?PHP echo $nid; ?>" target="_self">修改</a></font></div>
			</div>
			<div class="top_help">
				<div class="top_o">
					<font class="top_font">
						<a href="feedback.php" target="_blank">反馈</a> &nbsp;|&nbsp;
						<a href="help.php" target="_blank">帮助</a> &nbsp;|&nbsp;
						<a href="log_top.php" target="_top">退出</a>
					</font>

				</div>
				<div class="top_search">
					<form action="#" method="post" name="search" target="_blank" style="width:50px;">
						<input name="key" type="text" size="30" maxlength="30" placeholder="请在此处输入搜索内容" />
					</form>
				</div>
			</div>
		</div>