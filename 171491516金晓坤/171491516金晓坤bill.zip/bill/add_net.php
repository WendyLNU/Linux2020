<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>添加网址</title>
<link href="main_top.css" rel="stylesheet" type="text/css" />
</head>

<body background="images/net_a.jpg">
<div>
		<?PHP include("main_top.php"); ?>
		<?PHP 
			$nid = $_GET["nid"];
			$cla = $_GET["cla"];
		 ?>
		
<center>	
	<div style="border:solid 2px #999999; height:300px; width:500px; margin-top:20px;">

		<?PHP $nid = $_GET["nid"]; ?>
		<form action="add_net_save.php?nid=<?PHP echo $nid;?>&cla=<?PHP echo $cla; ?>" method="post" onsubmit="return CheckForm();">
		
			<table width="500" height="284" border="0" cellpadding="2" cellspacing="0">
			  <tr>
				<td colspan="2" align="center" style="font-size:30px; border-bottom:2px solid #FFFF00;">添加网址</td>
			  </tr>
			  <tr align="center">
				<td width="157" height="68">网络名</td>
				<td width="335"><input name="net_name" id="net_name" type="text" size="30" maxlength="100" /></td>
			  </tr>
			  <tr align="center">
				<td height="64" style="border-bottom:solid 2px #FFFF00;">地址</td>
				<td  style="border-bottom:solid 2px #FFFF00;">
					<input name="net_address" id="net_address" type="text" size="30" maxlength="200" />
				</td>
			  </tr>
			  <tr align="center">
				<td><input name="sub" type="submit" value="保存" /></td>
				<td><input name="back" type="button" value="返回" onclick="location.href='net.php?nid=<?PHP echo $nid; ?>'"/></td>
			  </tr>
		</table>
		</form>
	</div>
</center>
</div>
</body>
</html>

<script type="text/javascript">
	function CheckForm(){
		var c = document.getElementById("net_name");
			if(c.value.trim() == ""){
			alert("网络名不能为空");
			return false;
		}
		
		var c1 = document.getElementById("net_address");
			if(c1.value.trim() == ""){
			alert("网址不能为空");
			return false;
		}
	}
</script>