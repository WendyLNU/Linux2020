<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>bill管理</title>
<link href="bill.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="jquery-3.5.1.min.js"></script>
<script type="text/javascript">
      window.onload = function() {
          getHeight();//得到屏幕高度
       };
       function getHeight() {
             var net = document.getElementById('bill');//得到 net div
             var body_height = document.documentElement.clientHeight;//document.body.clientHeight����<!DOCTYPE html>�����»᷵��0
			 var body_width = document.documentElement.clientWidth;
             net.style.height = body_height + 'px';
			 net.style.width = body_width*0.6 + 'px';
			// alert(body_height);
         }

</script>

<?PHP 
		include("conn.php");
		$nid = $_GET["nid"];

?>
</head>
<body>
	<center>
	<div id="bill">
		<div id="nav" style="width:100%; height:10%;">
			<div style="height:100%; width:33%; float:left; background-color:#009999;"></div>
			<div style="height:100%; width:34%; float:left; background-color:#CC9900; font-size:30px; font-family:'新宋体';">账单管理</div>
			<div style="height:100%; width:33%; float:left; background-color:#CCCCCC;">
				<a href="main.php?nid=<?PHP echo $nid; ?>" target="_top">返回主菜单</a>
			</div>
		</div>
		
		<?PHP  
			$sql1 = "SELECT * FROM billT where id='$nid'";
			$in = 0.0;
			$out = 0.0;
			
			$result = mysql_query($sql1,$db) OR die (mysql_error($db));
			while($row = mysql_fetch_array($result)){ 
				if($row["bigClass"] == "收入"){
					$in = $in + $row["mon"];
				}else{
					$out = $out + $row["mon"];
				}
			}
		?>
		
		<div id="total" style="height:30%; width:100%; background-color:#0066CC;">
			<div style="width:4%; height:100%; float:left;"></div>
			<div style="width:96%; height:100%; float:left; background-color:#99CC00; text-align:left;">
				<div style="width:100%; height:45%;"></div>
				<div style="width:100%; height:12%; background-color:#FFFF00;">
					支出
				</div>
				<div style="width:100%; height:23%; background-color:#FFFFFF;">
					<font style="font-size:30px"><?PHP echo $out; ?>元</font>
				</div>
				<div style="width:100%; height:12%; background-color:#666666;">
					收入<?PHP echo $in; ?>
				</div>
				<div style="width:100%; height:8%;"></div>
			</div>
		</div>
		

		<div id="flu" style="height:49%; width:100%; background-color:#CCCCCC; padding-top:1%;" align="left">
		<?PHP 		
			$sql = "SELECT * FROM billT where id='$nid'";
			$result = mysql_query($sql,$db) OR die (mysql_error($db));		
			while($row = mysql_fetch_array($result)){ 
		?>
		
			<div style="width:30%; height:10%; background-color:#FF9900; margin:0% 1.5% 1% 1.5%; float:left;">
				<div style="height:100%; width:50%; float:left; background-color:#999999;">
					<?PHP echo $row["bigClass"]."----".$row["smallClass"]; ?>
				</div>
				<div style="height:100%; width:50%; float:left; background-color:#CC9900;" align="center">
					<?PHP echo $row["mon"]; ?>
				</div>
			</div>
			
		 <?PHP 
			}
			mysql_free_result($result);
			mysql_close($db);	
		 ?>
		</div>
		
		<div id="jyb" style="height:10%; width:100%; background-color:#999999;; margin:0; overflow:hidden;">
			<div style="width:20%; height:80%; margin-top:1%;">
				<a href="bill_input.php?nid=<?PHP echo $nid; ?>" target="_self">
				<button name="do"><font style="font-size:34px; font-family:'新宋体';">记一笔</font></button>
				</a>
			</div>
		</div>
	</div>
	</center>

</body>
</html>
