<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>记一笔</title>


<script type="text/javascript" src="jquery-3.5.1.min.js"></script>
<script type="text/javascript">
      window.onload = function() {
          getHeight();//得到屏幕高度
       };
       function getHeight() {
             var net = document.getElementById('input');//得到 net div
             var body_height = document.documentElement.clientHeight;//document.body.clientHeight����<!DOCTYPE html>�����»᷵��0
			 var body_width = document.documentElement.clientWidth;
             net.style.height = body_height + 'px';
			 net.style.width = body_width*0.6 + 'px';
			// alert(body_height);
         }

</script>

<link href="bill_input.css" rel="stylesheet" type="text/css" />
</head>

<?PHP 
	$nid = $_GET["nid"];
 ?>

<body style="background-color:#CCCCCC;">
	<center>
	<div id="input" style="background-color:#999999;">
		<div id="nav" style="background-color:#FFFF00;">
			<div id="back" align="left" onclick="location.href='bill.php?nid=<?PHP echo $nid; ?>'"> 
				<button name="back" style="height:100%; width:30%;">取&nbsp;消</button>
			</div>
			<div id="title">记一笔</div>
			<div id="save" align="right">
				<button name="save" style=" height:100%; width:30%;">保&nbsp;存</button>
			</div>
		</div>
		
		<div id="in_out">
			<div id="in">
				<div style="height:20%; width:100%;"></div>
				<a href="input_show.php?nid=<?PHP echo $nid; ?>" target="bill_iframe">
					<div style="height:60%; width:100%; font-size:24px;" >收入</div>
				</a>
				<div style="height:20%; width:100%;"></div>	
			</div>
			<div id="out">
				<div style="height:20%; width:100%;"></div>
				<a href="output_show.php?nid=<?PHP echo $nid; ?>" target="bill_iframe">
					<div style="height:60%; width:100%; font-size:24px;" >֧支出</div>
				</a>
				<div style="height:20%; width:100%;"></div>	
			</div>	
		</div>
		
		<div id="show">
			<iframe name="bill_iframe" id="bill_iframe" src="images/frame.jpeg.jpg" frameborder="0" width="100%" height="530px" scrolling="no">
		</div>
	</div>
	</center>
</body>
</html>
