<?PHP 
	$dno = $_GET["del_no"];
	$did = $_GET["nid"];
	
	include("conn.php");
	$sql = "SELECT * FROM nets where no={$dno}";
	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	$row = mysql_fetch_array($result);
	
	//�õ� $cla����
	$cla = $row["class"];
	
	//ɾ��nets���� no Ϊ dNo �ü�¼
	$sql_del2 = "Delete FROM nets where no={$dno}";
	$result = mysql_query($sql_del2,$db) OR die (mysql_error($db));
	
	mysql_free_result($result);
	mysql_close($db);	
	
	echo "<script>{document.location.href='del_net.php?nid=$did&cla=$cla'}</script>";
	
	

 ?>