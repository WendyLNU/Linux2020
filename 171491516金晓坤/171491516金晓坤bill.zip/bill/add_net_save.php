<?PHP
	$nid = $_GET["nid"];
	$cla = $_GET["cla"];
	$net_name = $_POST["net_name"];
	$net_address = $_POST["net_address"];

	include("conn.php");

	$sql="insert into nets(id,class,cont,address) values($nid,'$cla','$net_name','$net_address')";

	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	

	mysql_close($db);		
	
	if($result)
   		 echo "<script>{location.href='net.php?nid=$nid'} </script>";
	else 
 	   echo "<script>{window.alert('添加失败');location.href='add_net.php?nid=$nid&cla=$cla'} </script>";

	mysql_free_result($result);


?>