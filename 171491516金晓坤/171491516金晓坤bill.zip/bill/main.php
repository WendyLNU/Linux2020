<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>个人管理</title>
<link href="main_top.css" rel="stylesheet" type="text/css" />

<link href="main_body.css" rel="stylesheet" type="text/css" />


<link href="main_bottom.css" rel="stylesheet" type="text/css" />
</head>
	<div id="main">
		<?PHP include("main_top.php"); ?>
		<?PHP include("main_body.php"); ?>
		<?PHP include("main_bottom.php"); ?>
	</div>
	
<body background="images/mian_bg.jpg">
</body>
</html>
