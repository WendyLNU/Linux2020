
		<?php 
		
			$nid = $_GET["nid"];
		
			$mon = $_POST["mon"];
			$bigClass = $_POST["province"];
			if($bigClass == "未分类")
				$smaClass = "";
			else
				$smaClass= $_POST["city"];

			$content = $_POST["content"];
			$date = $_POST["date"];
		
			include("conn.php");
			$sql="insert into billT(id,mon,bigClass,smallClass,date,content) values($nid,$mon,'$bigClass','$smaClass','$date','$content')";
		
			$result = mysql_query($sql,$db) OR die (mysql_error($db));
			
		
			mysql_close($db);		
			
			if($result)
				 echo "<script>{location.href='bill.php?nid=$nid'} </script>";
			else 
			   echo "<script>{window.alert('添加失败');location.href='add_net.php?nid=$nid&cla=$cla'} </script>";
		
			mysql_free_result($result);

		 ?>
