	<?PHP
		 $nid = $_GET["nid"]; 
		include("conn.php");
		
		$sql = "SELECT * FROM user where id = '$nid'";
		$result = mysql_query($sql,$db) OR die (mysql_error($db));
		$row = mysql_fetch_array($result);
	?>

		<div class="top">
			<div class="top_log">
				<img src="images/log.png" style="height:100%; width:100%;"/>
			</div>
			<div class="top_info">
				<div class="top_info_id"><font class="top_font"><?PHP echo $row["user"]."(".$row["name"].")"; ?></font></div>
				<div><font class="top_font"><a href="updateinfo.php?nid=<?PHP echo $nid; ?>" target="_self">修改</a></font></div>
				<div style="margin-top:5px; color:"><a href="main.php?nid=<?PHP echo $nid; ?>" target="_top">返回主菜单</a></div>
			</div>
			<div class="top_help">
				<div class="top_o">
					<font class="top_font">
						<a href="feedback.php" target="_blank">反馈</a> &nbsp;|&nbsp;
						<a href="help.php" target="_blank">帮助中心</a> &nbsp;|&nbsp;
						<a href="log_top.php" target="_top">退出</a>
					</font>
				</div>
				<div class="top_search">
					<form action="#" method="post" name="search" target="_blank" style="width:50px;">
						<input name="key" type="text" size="30" maxlength="30" placeholder="请在此处输入查找内容" />
					</form>
				</div>
			</div>
		</div>