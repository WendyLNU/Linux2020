<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>删除网址</title>
<link href="main_top.css" rel="stylesheet" type="text/css" />

<link href="main_del.css" rel="stylesheet" type="text/css" />
</head>

<body background="images/note.jpg">
<div>
	<?PHP include("main_top.php"); ?>
	<div class="del">
		<div class="del_body">
		<?php 
			include("conn.php");
			$nid = $_GET["nid"];
			$cla = $_GET["cla"];
			
			$sql = "SELECT * FROM nets where id='$nid' and class='$cla'";
			$result = mysql_query($sql,$db) OR die (mysql_error($db));
			while($row = mysql_fetch_array($result)){
		?>
				<div class="a" style="background-image:url(images/div.jpg);">
					<div class="a_cont" style="width:100px; height:80px; text-align:center; line-height:80px;">
						<?PHP echo $row["cont"]; ?>
					</div>
					<div  name="del" class="a_del" style="width:100px; height:20px;">
						<input type="button" value="删除" style="padding:0px 35px 0px 35px"/>
						<input type="hidden" value="<?PHP echo $row["no"]; ?>"></div>
				</div>
		 <?PHP 
			 }
			 mysql_free_result($result);
			mysql_close($db);	
		 ?>
		</div>
		
		<div class="del_bottom" style="background-image:url(images/back.png);">
			<div class="back" onclick="location.href='net.php?nid=<?PHP echo $nid; ?>'" >
				返回
			</div>
		</div>
	</div>
</div>
</body>
</html>

<script type="text/javascript">
	window.onload = function(){
		var del_button = document.getElementsByName("del");
		for(var i = 0; i < del_button.length; i++){
			del_button[i].onclick = function(){
					var no = this.lastChild.value;
					var str="&del_no="+no;
					str = "del_net_sure.php?nid=<?PHP echo $nid; ?>"+str;
					location.href = str;
			}
		}
		

	}
</script>
