<?PHP  
	$nid = $_GET["nid"];
	$cla = $_POST["note_class"];


	include("conn.php");

	$sql="insert into notes_class(id,name) values({$nid},'$cla')";
					
	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	mysql_close($db);
	
	echo "<script>{location.href='note.php?nid=$nid&class=$cla'} </script>";
		

?>