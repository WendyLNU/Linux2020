<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>注册</title>
<script type="text/javascript" src="jquery-3.5.1.min.js"></script>
<script type="text/javascript">
      window.onload = function() {
          getHeight();//得到屏幕高度
       };
       function getHeight() {
             var net = document.getElementById('log');//得到 net div
             var body_height = document.documentElement.clientHeight;//document.body.clientHeight����<!DOCTYPE html>�����»᷵��0
			 var body_width = document.documentElement.clientWidth;
             net.style.height = body_height + 'px';
			 net.style.width = body_width + 'px';
			// alert(body_height);
         }

</script>
<link href="register.css" rel="stylesheet" type="text/css" />
</head>

<body background="images/log_bg.jpg">
	<?PHP 
		$mes=isset($_GET["mes"])?$_GET["mes"] : "";
		$u=isset($_GET["u"])?$_GET["u"] : "";
	 ?>

	<div id="log">
		<div id="top">
			<div id="top_log"><img src="images/log.png" style="height:100%; width:100%;"></div>
			<div id="top_info" align="right">
				<a href="#">关于我们</a>&nbsp;|&nbsp;<a href="#">了解更多</a>
			</div>
		</div>
		<div id="body">
			<div id="body_left">
				<div style="height:20%; width:80%;"></div>
				<div class="body_left_info">
					<p></p>
					<p>没有什么能够阻挡</p>
					<p>你对自由得向往</p>
					<p>天马行空得生涯</p>
					<p>你的心了无牵挂</p>
					<p class="log_in_pic">摘自《蓝莲花》</p>
				</div>
			</div>
			<div id="body_right">
				<div style="height:10%; width:100%;"></div>
				<div class="body_right_log">
						<form id="log_form" method="post" action="registerAcount.php" onsubmit="return CheckForm();">
						<table height="100%" width="60%"  border="0" cellspacing="0" cellpadding="2" align="center" style="opacity:0.8;">
						  <tr align="center" bgcolor="#F9FBFE" bordercolor="#999999">
							<td height="30px" colspan="2">
								<h2>成员注册</h2>
								<p id="tip" style="color:#CC0000; font-size:9px; visibility:<?PHP if($res==""){echo "hidden";}else{echo "visible"; } ?>">
									<?PHP echo $mes; ?>&nbsp;
								</p>
							</td>
						  </tr>
						  <tr align="center"  bgcolor="#F9FBFE">
							<td width="53" height="35">账 号</td>
							<td width="247">
								<input name="user" id="user" type="text" size="30" maxlength="30" height="40px" placeholder="请在此处输入账号"
								 value="<?PHP if($u!="") echo $u; ?>">
							</td>
						  </tr>
						  <tr align="center"  bgcolor="#F9FBFE">
							<td width="53" height="35">用户名</td>
							<td width="247">
								<input name="username" id="username" type="text" size="30" maxlength="30" height="40px" placeholder="请输入用户名"
								 value="<?PHP if($u!="") echo $u; ?>">
							</td>
						  </tr>
						  <tr align="center"  bgcolor="#F9FBFE">
							<td height="35">密 码</td>
							<td><input name="pas" id="pas" type="password" size="30" maxlength="30" height="40px"  placeholder="请在此处输入密码"></td>
						  </tr>
						  <tr align="center"  bgcolor="#F9FBFE">
							<td height="35">密 码</td>
							<td><input name="pas2" id="pas2" type="password" size="30" maxlength="30" height="40px"  placeholder="请在输入一遍您的密码"></td>
						  </tr>
						  <tr align="center"  bgcolor="#F9FBFE">
							<td height="79" colspan="2">
							
								<a href="log_top.php" target="_self">
								<input name="register" type="button" value="返回"> 
								 </a> 
								&nbsp;&nbsp;
								<input name="submit" type="submit" value="注册">


							</td>
						  </tr>
						</table>
						</form>
				</div>
				<div style="height:10%; width:100%;"></div>
			</div>
		</div>
		
		<div id="bottom" align="center">
			<a href="#">联系我们</a>&nbsp;|&nbsp;<a href="#">帮助中心</a>
		</div>
	</div>
</body>
</html>

<script type="text/javascript">
	function CheckForm(){
		var tip = document.getElementById("tip");
		var user = document.getElementById('user');
		if(user.value.trim() == ""){
		
			tip.firstChild.nodeValue="用户名不能为空";
			tip.style.visibility='visible';
			return false;
		}
		
		var pas = document.getElementById('pas');
		if(pas.value.trim() == ""){
			
			tip.firstChild.nodeValue="密码不能为空";
			tip.style.visibility='visible';
			return false;
		}
		
		var pas2 = document.getElementById('pas2');
		if(pas2.value.trim() != pas.value.trim()){
			
			tip.firstChild.nodeValue="密码不一致";
			tip.style.visibility='visible';
			return false;
		}	
		
	}
</script>