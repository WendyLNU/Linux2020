<?PHP  
	include("conn.php");
	$nid = $_GET["nid"];
	$cla = $_POST["class"];
	
	$sql="insert into net_class(id,class) values($nid,'$cla')";

	$result = mysql_query($sql,$db) OR die (mysql_error($db));
	
	if($result)
   		 echo "<script>{location.href='net.php?nid=$nid'} </script>";
	else 
 	   echo "<script>{window.alert('���ʧ��');location.href='net_addclass.php?nid=$nid'} </script>";
?>