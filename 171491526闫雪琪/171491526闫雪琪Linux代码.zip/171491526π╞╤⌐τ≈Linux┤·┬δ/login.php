<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�ޱ����ĵ�</title>
</head>

<body>

<?php

include("conn.php");
$na=$_POST["username"];
$po=$_POST["password"];
$sql = "SELECT password FROM users where name='$na'";
$result = mysql_query($sql,$db) OR die (mysql_error($db));
$row = mysql_fetch_array($result);
/*$rs=new com("adodb.recordset");
$rs->open($sql,$db,1,1);//ִ�����,���ؼ�¼��*/
//$row = mysql_fetch_array($result);
//$x=0;
    
if($po== $row["password"])
	echo "<script>{alert('��½�ɹ�');location.href='default.php?x=1&name=$na'} </script>";
else 
    echo "<script>{alert('������˺Ŵ���');location.href='main2.php'} </script>";
  
mysql_free_result($result);
mysql_close($db);
?>
</table>
</body>
</html>
