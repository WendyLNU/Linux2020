<table width="778" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td width="274" rowspan="2"  valign="top" align="center"><?php 
	@$na=$_GET["name"];
	@$xx=$_GET["x"];
	include("left_timer.php");
	include("left_seek.php");
	include("left_sizn.php");

	?></td>
    <td width="504" bgcolor="#FFFFCC"><a href="default.php?x=<?php echo $xx ?>&name=<?php echo $na ?> ">�Ƽ�</a>&nbsp;&nbsp;<a href="default2.php?x=<?php echo $xx ?>&name=<?php echo $na ?> ">����</a>&nbsp;&nbsp;<a href="default3.php?x=<?php echo $xx ?>&name=<?php echo $na ?> ">����</a></td>
  </tr>
  <tr>
  <td>
<?php /*
$sql = "Select * From bigclass where homepage";
$rs=new com("adodb.recordset");
$rs->open($sql,$db,1,1);//ִ�����,���ؼ�¼��
while(! $rs->eof)
{
$ccc=$rs->Fields("bigclassname")->value; 
$nnn=$rs->Fields("rmax")->value; 
$aaa=$rs->Fields("ad")->value; */
ad($xx,$na);/*
$rs->MoveNext(); 
}
$rs=NULL;*/
?>
</td>
</tr>
</table>
