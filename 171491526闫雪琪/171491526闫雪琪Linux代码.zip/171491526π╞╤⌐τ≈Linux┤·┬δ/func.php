<?php function ad($xx,$na){?>

    <table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr bgcolor="#FFFFFF">
   
    
  </tr> 
<?php
include("conn.php");
$sqlf = "Select  * From news ";
$result = mysql_query($sqlf,$db) OR die (mysql_error($db));
$js=1;
while($row = mysql_fetch_array($result))
{
if($js<20){
if($js%2==0)
$ys='FFFFCC';
else
$ys="FFFFFF";
?>  
  <tr bgcolor="#<?php echo $ys ?>">
  <td ><?php echo $js ?></td>
   <td><a href="news_disp.php?xwh=<?php echo $row["NID"];?>&x=<?php echo $xx ?>&name=<?php echo $na ?>" target="_blank"><?php echo $row["title"];?></a></td>
    <td ><?php echo $row["infotime"];?></td>
    <td ><?php echo $row["hits"];?></td>
  </tr>
<?php
 $js++;
}
}
mysql_free_result($result);
mysql_close($db);
?>  
</table>

<embed src="images/<?php echo $a?>" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" width="578" height="80">
</object>
<?php }?>