<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3">���Ű��</td></tr>
</table>
<table width="200" border="0" cellspacing="0" cellpadding="1">
<?php
$xx=$_GET["x"];
$na=$_GET["name"];
$sql = "select bigclassname,count(*) as bc from news group by bigclassname";
$result = mysql_query($sql,$db) OR die (mysql_error($db));
$js=1;
while($row = mysql_fetch_array($result))
{
if($js%2==0)
$ys='FFFFCC';
else
$ys="FFFFFF";
?>
  <tr bgcolor="#<?php echo $ys ?>">
    <td width="100"><a href="class_list.php?cn=<?php echo $row["bigclassname"];?>&x=<?php echo $xx ?>&name=<?php echo $na ?>" target="_blank"><?php echo $row["bigclassname"];?></a></td> 
	<td width="100"><?php echo $row["bc"];?></td>
  </tr>
<?php

$js++;
}
mysql_free_result($result);

?> 
  
</table>