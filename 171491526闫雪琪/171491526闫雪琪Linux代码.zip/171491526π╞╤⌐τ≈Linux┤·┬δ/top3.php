<?php
@$na=$_GET["name"];
@$xx=$_GET["x"];
?>

<center>
  <table width="778" border="0" cellspacing="0" cellpadding="2" background="images/yun.gif">
    <tr>
      <td width="474">&nbsp;</td>
      <td width="184" height="2" valign="top"  align="right"></td>
      <td width="44" valign="top"></td>
      <td width="60" valign="top"></td>
    </tr>
    <tr>
      <td height="50">&nbsp;</td>
      <td height="100" colspan="3" valign="bottom" align="right"></td>
    </tr>
  </table>
</center>


  </tr>
</table>
