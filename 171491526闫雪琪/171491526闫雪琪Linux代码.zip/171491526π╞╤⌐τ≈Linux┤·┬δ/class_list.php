<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>���ŷ���</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#535353" leftmargin="0" topmargin="0">
<?php 
include("conn.php");//$db
include("top.php");
$ccc=$_GET["cn"];
$xx=$_GET["x"];
$na=$_GET["name"];
?>


<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#00FF33">
    <th colspan="5"><?php echo $ccc ?></th>
  </tr>
  <tr bgcolor="#99FF00"> 
    <td width="78" align="center">NID</td>
    <td width="403" align="center">����</td>
    <td width="105" align="center">����</td>
    <td width="97" align="center">����ʱ��</td>
    <td width="75" align="center">�����</td>
  </tr>
<?php
$sql = "Select * From news where bigclassname='$ccc' ";
$result = mysql_query($sql,$db) OR die (mysql_error($db));//ִ�����,���ؼ�¼��
while($row = mysql_fetch_array($result))
{
?>  
  <tr bgcolor="#FFFFFF" height="25">
    <td><?php echo $row["NID"];?></td>
    <td><a href="news_disp.php?xwh=<?php echo $row["NID"];?>&x=<?php echo $xx ?>&name=<?php echo $na ?>" target="_blank" title="<?php echo $row["title"];?>"><?php echo $row["title"];?></a></td>
    <td><?php echo $row["user"];?></td>
    <td><?php echo $row["infotime"];?></td>
    <td><?php echo $row["hits"];?></td>
  </tr>
<?php
 
}
mysql_free_result($result)

?>
  
</table>

</body>
</html>
