<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>�������</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#535353" leftmargin="0" topmargin="0">
<?php
include("conn.php");

include("top3.php");
$xwid=$_GET["xwh"];
$xx=$_GET["x"];
$na=$_GET["name"];
$sqlupd="update news set hits=hits+1 where nid=$xwid";
$result = mysql_query($sqlupd,$db) OR die (mysql_error($db));

$sql = "Select * From news where nid=$xwid";
$result = mysql_query($sql,$db) OR die (mysql_error($db));
$row = mysql_fetch_array($result);
?>
<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#006600">
    <th><?php echo $row["title"];?></th>
  </tr>
  <tr bgcolor="#009900">
  <td>
  �������<?php echo $row["bigclassname"];?><br>
  ���ߣ�<?php echo $row["user"];?><br>
  ����ʱ�䣺<?php echo $row["infotime"];?><br>
  ����ʣ�<?php echo $row["hits"];?>
  </td>    
  </tr>
  <tr bgcolor="#FFFFFF">
    <td><?php echo $row["content"];?></td>
  </tr>
<?php
mysql_free_result($result)


?>
</table>


<table width="778" border="0" cellspacing="0" cellpadding="2" bgcolor="#FFFF99" align="center">
  <tr>
    <td width="80" valign="top">�������ۣ�</td>
    <td width="690"  valign="middle">
	<form action="discuss_save.php?xwh=<?php echo $xwid ?>&x=<?php echo $xx ?>&name=<?php echo $na ?>" method="post" name="formadd" onSubmit="return myFun2();">
	  <input name="pl" type="text" value="" size="80" align="bottom">	
	<input name="" type="submit" value="�ύ">
	</form>
	</td>   
  </tr>
</table>


<table width="778" border="0" cellspacing="0" cellpadding="2" align="center" >
  <tr bgcolor="#00CCCC">
    <td>������</td>
  </tr>
<?php
include("conn.php");
$sql = "SELECT * FROM discuss where nid=$xwid";
$result = mysql_query($sql,$db) OR die (mysql_error($db));/*
$rs=new com("adodb.recordset");
$rs->open($sql,$db,1,1);*/
while($row = mysql_fetch_array($result))
{
?>
  <tr bgcolor="#FFFFCC">
  <td><?php echo $row["content"];?></td>
  <td>�����ߣ�<?php echo $row["user"];?></td> 
  </tr>
<?php

}

?>
</table>


</body>
</html>
<script language="javascript">
function myFun2(){
na=document.formadd.pl.value;
if(na.trim()==""){
	alert("���������ݣ�����");
	document.formadd.pl.focus();
	return false;
	}
return true;
}
</script>