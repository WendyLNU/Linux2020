<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>������ѧ������վ</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFFF" topmargin="0" leftmargin="0">
<?php
@$xx=$_GET["x"];
//@$xx = !empty($_GET["$x"]) ? $_GET["$x"] : 0; 
//echo $xx;
include("conn.php");//$db
include("func3.php");//ad
if($xx!=1)
include("top.php");
else
include("top2.php");
include("body.php");

?>
</body>
</html>
