<center>
  <table width="778" border="0" cellspacing="0" cellpadding="2" background="images/yun.gif">
    <tr>
      <td width="616">&nbsp;</td>
      <td width="54" height="2"><div align="left"><strong><a href="main2.php?x=0">��½</a>|</strong>|</div></td>
      <td width="53"><strong><a href="main.php">ע��</a>|</strong></td>
      <td width="39"><strong>����</strong></td>
    </tr>
    <tr>
      <td height="50">&nbsp;</td>
      <td height="100" colspan="3" valign="bottom" align="right">��½��ɷ�������</td>
    </tr>
  </table>
</center>







  </tr>
</table>
