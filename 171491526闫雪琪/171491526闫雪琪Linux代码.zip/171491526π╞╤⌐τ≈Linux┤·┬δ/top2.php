<?php
@$na=$_GET["name"];
@$xx=$_GET["x"];
?>

<center>
  <table width="778" border="0" cellspacing="0" cellpadding="2" background="images/yun.gif">
    <tr>
      <td width="474">&nbsp;</td>
      <td width="163" height="2" valign="top"  align="right"><strong><?php echo $na ?>&nbsp;</strong></td>
      <td width="65" valign="top"><strong>�ѵ�¼</strong></td>
      <td width="60" valign="top" align="right"><strong><a href="main3.php?x=<?php echo $xx ?>&name=<?php echo $na ?> " target="_blank">�޸�����</a></strong></td>
    </tr>
    <tr>
      <td height="17">&nbsp;</td>
      <td height="17" colspan="3" valign="bottom" align="right"><strong><a href="default.php?x=0&name=<?php echo $na ?>">�˳���¼</a></strong></td>
    </tr>
    <tr>
      <td height="50">&nbsp;</td>
      <td height="100" colspan="3" valign="bottom" align="right"><a href="news_addA6.php?x=<?php echo $xx ?>&name=<?php echo $na ?> ">��������</a></td>
    </tr>
  </table>
</center>



  </tr>
</table>
