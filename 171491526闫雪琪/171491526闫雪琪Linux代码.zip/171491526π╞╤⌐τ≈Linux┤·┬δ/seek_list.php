<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>���Ų�ѯ</title>
<link href="css.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#535353" leftmargin="0" topmargin="0">
<?php 
include("conn.php");//$db
include("top.php");
$key=$_POST["kkk"];
$pos=$_POST["ppp"];
?>


<table width="778" border="0" cellspacing="0" cellpadding="2" align="center">
  <tr bgcolor="#00FF33">
    <th colspan="5"><?php echo "���ҹؼ���{$key}���"?></th>
  </tr>
  <tr bgcolor="#99FF00"> 
    <td width="78" align="center">NID</td>
    <td width="403" align="center">����</td>
    <td width="105" align="center">����</td>
    <td width="97" align="center">����ʱ��</td>
    <td width="75" align="center">�����</td>
  </tr>
<?php
if ($pos=="bt"){
$sql = "Select * From news where title like '%{$key}%' ";}
if ($pos=="nr"){
$sql = "Select * From news where content like '%{$key}%' ";}
$result = mysql_query($sql,$db) OR die (mysql_error($db));
while($row = mysql_fetch_array($result))
{
?>  
  <tr bgcolor="#FFFFFF" height="25">
    <td><?php echo $row["NID"];?></td>
    <td><a href="news_disp.php?xwh=<?php echo $row["NID"];?>" target="_blank" title="<?php echo $row["title"];?>"><?php echo $row["title"];?></a></td>
    <td><?php echo $row["user"];?></td>
    <td><?php echo $row["infotime"];?></td>
    <td><?php echo $row["hits"];?></td>
  </tr>
<?php

}

?>
  
</table>

</body>
</html>
