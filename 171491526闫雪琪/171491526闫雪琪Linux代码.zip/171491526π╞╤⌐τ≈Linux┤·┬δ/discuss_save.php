<?php
include("conn.php");

$xx=$_GET["x"];

$nn=$_GET["name"];
$nd=$_GET["xwh"];
$pl=$_POST["pl"];
echo $xx;
$result=1;
if($xx==1){
$sq="select * from discuss order by no desc";
$result = mysql_query($sq,$db) OR die (mysql_error($db));
$row = mysql_fetch_array($result);
/*while(! $rs->eof)
{
$no=$rs->Fields("title")->value;

$rs->MoveNext(); 
}
*/



$no=$row["no"];
$no++;
$sql="insert into discuss (no,nid,content,user) values('$no','$nd','$pl','$nn')";
//echo $sql;exit();
//$result=$db->Execute($sql);
//$result�ǲ����ͱ�����������ֵ������ʾ��ɾ���Ƿ�ɹ���
$result = mysql_query($sql,$db) OR die (mysql_error($db));
}
else{
$result=0;
}
if($result)
    echo "<script>{alert('���ӳɹ�');location.href='news_disp.php?xwh=$nd&x=$xx&name=$nn'} </script>";
else 
    echo "<script>{alert('please login');history.back();} </script>";

?>